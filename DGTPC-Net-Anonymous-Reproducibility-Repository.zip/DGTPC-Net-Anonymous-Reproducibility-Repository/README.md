# DGTPC-Net Anonymous Reproducibility Repository

This repository contains the data-construction, model-training, calibration,
evaluation, uncertainty-analysis, and reporting code for:

> Distillation Guided Temporal Prototype Calibration Network for Early Student
> Dropout Risk Prediction in Online Higher Education

The implementation follows the manuscript protocol: midpoint eligibility,
student-grouped boundaries, training-only CatBoost distillation, independent
calibration and threshold selection, temporal transfer, retraining ablations,
fixed-model sensitivity analyses, and paired student-cluster bootstrap
inference.

## Repository contents

- `configs/`: fixed manuscript settings and experiment definitions.
- `src/dgtpc/`: cohort construction, feature engineering, model, losses,
  grouped splits, calibration, thresholds, metrics, bootstrap, training, and
  reporting modules.
- `scripts/`: command-line launchers for data preparation, all experiments,
  and repository validation.
- `tests/`: deterministic checks for cohort logic, grouped boundaries,
  probability metrics, threshold selection, calibration, and model source.
- `manuscript_targets/`: machine-readable values reported in Tables 3, 7, 8,
  10, 11, 13, 14, and 15.
- `artifacts/reference_runs/`: reference transcripts that document the expected
  command sequence, stage names, and output fields.
- `provenance/`: artifact-status and reproducibility-boundary statements.
- `REPRODUCIBILITY.md`: manuscript-to-command and output-file mapping.
- `DATA.md`: public dataset identifiers, required source tables, and local data
  boundary.

Raw OULAD files, trained weights, fold predictions, and generated outputs are
not distributed in the archive. They are produced locally by the commands
below and are excluded from version control.

## Environment

Python 3.11 is recommended.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.lock
python -m pip install -e .
```

Exact versions are recorded in `requirements.lock`; compatible ranges are
recorded in `requirements.txt`, `environment.yml`, and `pyproject.toml`.

## Data acquisition

OULAD is publicly available from the Open University and Figshare. The download
command resolves the archive through the Figshare article API and records the
received SHA-256 digest locally:

```bash
python -m dgtpc.cli download --output-dir data/raw
```

If the archive has already been downloaded, unpack it into `data/raw` so that
the seven CSV tables are directly present in that directory.

## Build the midpoint risk set and model inputs

```bash
python -m dgtpc.cli prepare \
  --config configs/paper.yaml \
  --raw-dir data/raw \
  --output-dir data/processed
```

The preparation stage creates:

- `cohort.csv`: eligible student-module-presentation records and outcomes;
- `tabular.csv`: static, registration, course, VLE, and assessment features;
- `sequences.npz`: weekly activity tensor and masks;
- `reliability.csv`: pre-horizon evidence-availability indicators;
- `feature_manifest.json`: feature names, activity channels, and construction
  settings;
- `cohort_audit.json`: sequential exclusions and cohort counts.

## Run the complete manuscript protocol

```bash
bash scripts/run_all.sh
```

The launcher executes student-grouped cross-validation, CCC transfer,
2013-to-2014 transfer, retraining ablations, fixed-model robustness,
source-only calibration matching, paired bootstrap inference, and table and
figure export. Each stage writes its own timestamped log under `outputs/logs`.

The same stages may be run individually:

```bash
python -m dgtpc.cli run --config configs/main_cv.yaml
python -m dgtpc.cli run --config configs/ccc_transfer.yaml
python -m dgtpc.cli run --config configs/temporal_transfer.yaml
python -m dgtpc.cli run --config configs/ablations.yaml
python -m dgtpc.cli run --config configs/robustness.yaml
python -m dgtpc.cli report --config configs/paper.yaml
```

## Protocol invariants

1. Prediction is restricted to students still enrolled at the midpoint horizon.
2. Recorded features are restricted to dates no later than the horizon.
3. Complete `id_student` groups remain together in every split.
4. Initial fitting uses A, epoch selection uses B, final refitting uses A union B,
   calibration uses C, and threshold selection uses D.
5. Teacher probabilities are grouped out-of-fold within A or A union B.
6. C, D, and target outcomes never enter predictor fitting.
7. Calibration candidates are selected independently for DGTPC-Net and
   standalone CatBoost by grouped validation NLL within C.
8. Test metrics are calculated before aggregation; probabilities are not
   averaged into an ensemble.
9. Temporal uncertainty uses paired student-cluster resampling with the same
   draws for both models.

## Validation

```bash
bash scripts/validate_repository.sh
```

The validation command checks Python syntax, repository structure, anonymous
metadata, deterministic utility tests, manuscript-target schemas, and the
absence of generated data or trained weights.

## Reference transcripts

Files in `artifacts/reference_runs` are reference transcripts, not
machine-executed benchmark evidence. They show the required stage ordering and
the manuscript-aligned output schema so that an independent run can be checked
before publication. Execute `scripts/run_all.sh` to generate run-specific logs,
then retain those generated logs as the execution record.

## Data and scope

The repository uses only OULAD. Module- and year-based tests are internal
transfer assessments within OULAD and are not cross-institutional validation.
The assessment-score features follow the manuscript's stated assumption that a
score recorded for an assessment submitted by the midpoint was available at
prediction time.

For the exact relationship between pipeline stages and manuscript tables, see
`REPRODUCIBILITY.md`.


