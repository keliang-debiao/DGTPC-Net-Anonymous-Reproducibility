# Anonymous review boundary

The repository contains no author names, affiliations, email addresses,
institutional account identifiers, absolute user paths, host names, or private
repository links. Public dataset identifiers and bibliographic metadata are
retained because they are necessary for independent data acquisition.

