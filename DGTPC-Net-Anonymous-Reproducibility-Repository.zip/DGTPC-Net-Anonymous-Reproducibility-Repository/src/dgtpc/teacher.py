from __future__ import annotations

import numpy as np
from catboost import CatBoostClassifier

from .preprocess import build_preprocessor
from .splits import teacher_oof_folds


def catboost_parameters(config: dict, seed: int) -> dict:
    parameters = dict(config["baselines"]["catboost"])
    parameters.update(
        {
            "loss_function": "Logloss",
            "eval_metric": "Logloss",
            "random_seed": int(seed),
            "allow_writing_files": False,
            "thread_count": -1,
        }
    )
    return parameters


def grouped_teacher_oof(
    features: np.ndarray,
    target: np.ndarray,
    groups: np.ndarray,
    config: dict,
) -> np.ndarray:
    prediction = np.full(len(target), np.nan, dtype=float)
    seed = int(config["splits"]["partition_seed"])
    folds = int(config["splits"]["teacher_folds"])
    for train, holdout in teacher_oof_folds(target, groups, seed, folds):
        model = CatBoostClassifier(**catboost_parameters(config, seed))
        model.fit(features[train], target[train])
        prediction[holdout] = model.predict_proba(features[holdout])[:, 1]
    if np.isnan(prediction).any():
        raise AssertionError("Teacher OOF probabilities are incomplete")
    return prediction


def grouped_teacher_oof_from_frame(
    frame,
    target: np.ndarray,
    groups: np.ndarray,
    manifest: dict,
    config: dict,
) -> np.ndarray:
    prediction = np.full(len(target), np.nan, dtype=float)
    seed = int(config["splits"]["partition_seed"])
    folds = int(config["splits"]["teacher_folds"])
    for train, holdout in teacher_oof_folds(target, groups, seed, folds):
        preprocessor = build_preprocessor(manifest).fit(frame.iloc[train])
        x_train = preprocessor.transform(frame.iloc[train])
        x_holdout = preprocessor.transform(frame.iloc[holdout])
        model = CatBoostClassifier(**catboost_parameters(config, seed))
        model.fit(x_train, target[train])
        prediction[holdout] = model.predict_proba(x_holdout)[:, 1]
    if np.isnan(prediction).any():
        raise AssertionError("Teacher OOF probabilities are incomplete")
    return prediction


def fit_standalone_catboost(
    train_features: np.ndarray,
    train_target: np.ndarray,
    config: dict,
    seed: int,
) -> CatBoostClassifier:
    model = CatBoostClassifier(**catboost_parameters(config, seed))
    model.fit(train_features, train_target)
    return model

