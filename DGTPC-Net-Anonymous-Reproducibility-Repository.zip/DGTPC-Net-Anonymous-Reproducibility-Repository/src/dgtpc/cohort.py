from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd


KEYS = ["code_module", "code_presentation", "id_student"]


@dataclass(frozen=True)
class CohortResult:
    cohort: pd.DataFrame
    audit: dict


def usable_integer(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.notna() & np.isfinite(numeric) & np.isclose(numeric, np.round(numeric))


def construct_midpoint_cohort(
    student_info: pd.DataFrame,
    registration: pd.DataFrame,
    courses: pd.DataFrame,
    midpoint_fraction: float = 0.5,
) -> CohortResult:
    frame = student_info.merge(registration, on=KEYS, how="inner", validate="one_to_one")
    frame = frame.merge(
        courses,
        on=["code_module", "code_presentation"],
        how="left",
        validate="many_to_one",
    )
    if frame["module_presentation_length"].isna().any():
        raise ValueError("Missing module presentation length after course merge")
    frame["horizon"] = np.floor(
        midpoint_fraction * pd.to_numeric(frame["module_presentation_length"], errors="raise")
    ).astype(int)

    reg_usable = usable_integer(frame["date_registration"])
    unreg_usable = usable_integer(frame["date_unregistration"])
    unreg_recorded = frame["date_unregistration"].notna()
    reg = pd.to_numeric(frame["date_registration"], errors="coerce")
    unreg = pd.to_numeric(frame["date_unregistration"], errors="coerce")
    final = frame["final_result"].astype(str)
    recognized = final.isin(["Withdrawn", "Pass", "Distinction", "Fail"])

    early_withdrawal = unreg_usable & (unreg <= frame["horizon"])
    other_exclusion = (~early_withdrawal) & (
        (~reg_usable)
        | (reg > frame["horizon"])
        | ((final == "Withdrawn") & (~unreg_usable))
        | ((final != "Withdrawn") & unreg_recorded)
        | (unreg_usable & reg_usable & (unreg < reg))
        | (~recognized)
        | (unreg_recorded & (~unreg_usable))
    )
    eligible = ~(early_withdrawal | other_exclusion)

    frame["eligibility_status"] = np.select(
        [early_withdrawal, other_exclusion, eligible],
        ["withdrawn_on_or_before_horizon", "other_exclusion", "eligible"],
        default="unresolved",
    )
    cohort = frame.loc[eligible].copy()
    cohort["target"] = (cohort["final_result"] == "Withdrawn").astype(np.int8)
    cohort["presentation_year"] = (
        cohort["code_presentation"].astype(str).str.extract(r"(\d{4})", expand=False).astype(int)
    )
    cohort["record_id"] = (
        cohort["code_module"].astype(str)
        + "__"
        + cohort["code_presentation"].astype(str)
        + "__"
        + cohort["id_student"].astype(str)
    )
    if cohort["record_id"].duplicated().any():
        raise ValueError("record_id is not unique")
    if not ((cohort["target"] == 0) | (unreg.loc[eligible] > cohort["horizon"])).all():
        raise AssertionError("Positive outcomes must occur after the midpoint horizon")

    audit = {
        "raw_registration_records": int(len(frame)),
        "raw_withdrawn_outcomes": int((final == "Withdrawn").sum()),
        "withdrawn_on_or_before_horizon": int(early_withdrawal.sum()),
        "other_eligibility_exclusions": int(other_exclusion.sum()),
        "eligible_records": int(len(cohort)),
        "eligible_unique_students": int(cohort["id_student"].nunique()),
        "subsequent_withdrawals": int(cohort["target"].sum()),
        "eligible_event_proportion": float(cohort["target"].mean()),
    }
    if audit["raw_registration_records"] != (
        audit["withdrawn_on_or_before_horizon"]
        + audit["other_eligibility_exclusions"]
        + audit["eligible_records"]
    ):
        raise AssertionError("Sequential cohort counts do not sum to raw registrations")
    return CohortResult(cohort=cohort.reset_index(drop=True), audit=audit)


def cohort_slice_audit(cohort: pd.DataFrame, mask: pd.Series) -> dict:
    part = cohort.loc[mask]
    return {
        "eligible_records": int(len(part)),
        "eligible_unique_students": int(part["id_student"].nunique()),
        "subsequent_withdrawals": int(part["target"].sum()),
        "eligible_event_proportion": float(part["target"].mean()) if len(part) else math.nan,
    }

