from __future__ import annotations

import numpy as np


def holm_adjust(p_values: np.ndarray) -> np.ndarray:
    p_values = np.asarray(p_values, dtype=float)
    order = np.argsort(p_values)
    adjusted = np.empty_like(p_values)
    running = 0.0
    total = len(p_values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (total - rank) * p_values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted


def cluster_multiplicity(groups: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    unique = np.unique(groups)
    sampled = rng.choice(unique, size=len(unique), replace=True)
    values, counts = np.unique(sampled, return_counts=True)
    multiplicity = dict(zip(values.tolist(), counts.tolist()))
    return np.asarray([multiplicity.get(value, 0) for value in groups], dtype=float)


def paired_cluster_bootstrap(
    groups: np.ndarray,
    statistic,
    replicates: int = 10000,
    seed: int = 20260711,
    confidence_level: float = 0.95,
) -> dict[str, float | np.ndarray]:
    rng = np.random.default_rng(seed)
    observed = float(statistic(np.ones(len(groups), dtype=float)))
    distribution = []
    attempts = 0
    while len(distribution) < replicates:
        attempts += 1
        if attempts > replicates * 20:
            raise RuntimeError("Too many invalid bootstrap replicates")
        weight = cluster_multiplicity(groups, rng)
        try:
            value = float(statistic(weight))
        except ValueError:
            continue
        if np.isfinite(value):
            distribution.append(value)
    distribution = np.asarray(distribution, dtype=float)
    alpha = 1.0 - confidence_level
    low, high = np.quantile(distribution, [alpha / 2.0, 1.0 - alpha / 2.0])
    centered = distribution - distribution.mean()
    p_value = (1.0 + np.sum(np.abs(centered) >= abs(observed))) / (replicates + 1.0)
    return {
        "effect": observed,
        "ci_low": float(low),
        "ci_high": float(high),
        "p_value": float(p_value),
        "distribution": distribution,
    }

