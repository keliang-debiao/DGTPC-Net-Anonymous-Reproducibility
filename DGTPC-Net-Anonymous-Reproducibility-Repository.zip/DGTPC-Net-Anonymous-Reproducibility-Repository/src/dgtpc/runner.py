from __future__ import annotations

import json
import logging
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from .baselines import fit_classical, fit_neural_baseline
from .calibration import MAPPINGS, select_calibrator
from .config import load_config
from .dataset import PreparedData, load_prepared
from .metrics import evaluate, probability_metrics
from .model import ForwardControl
from .preprocess import build_preprocessor
from .splits import grouped_folds, make_development_split
from .statistics import holm_adjust, paired_cluster_bootstrap
from .thresholds import select_macro_f1, select_recall_constrained, threshold_grid
from .training import _predict_arrays, _transformed, fit_dgtpc
from .utils import set_seed, write_json


def _logger(output_dir: Path, name: str) -> logging.Logger:
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(f"dgtpc.{name}.{id(output_dir)}")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)sZ | %(levelname)s | %(message)s")
    file_handler = logging.FileHandler(output_dir / f"{name}.log", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    return logger


def _development_split(data: PreparedData, config: dict):
    settings = config["splits"]
    return make_development_split(
        data.target,
        data.groups,
        int(settings["partition_seed"]),
        list(settings["A_folds"]),
        list(settings["B_folds"]),
        list(settings["C_folds"]),
        list(settings["D_folds"]),
    )


def _transfer_indices(data: PreparedData, experiment: dict) -> tuple[np.ndarray, np.ndarray]:
    frame = data.tabular
    protocol = experiment["protocol"]
    if protocol == "held_out_module":
        target_mask = frame["code_module"].astype(str) == str(experiment["target_module"])
        source_mask = ~target_mask
    elif protocol == "presentation_year_transfer":
        target_mask = frame["presentation_year"].astype(int) == int(experiment["target_year"])
        source_mask = frame["presentation_year"].astype(int) == int(experiment["source_year"])
    else:
        raise KeyError(protocol)
    target = np.flatnonzero(target_mask.to_numpy())
    target_students = set(data.groups[target].tolist())
    source_mask = source_mask.to_numpy() & np.asarray(
        [student not in target_students for student in data.groups], dtype=bool
    )
    source = np.flatnonzero(source_mask)
    return source, target


def _fit_candidate_maps(y: np.ndarray, p: np.ndarray, names: list[str], minimum: int):
    mappings = {}
    for name in names:
        if name == "isotonic" and len(y) < minimum:
            continue
        mappings[name] = MAPPINGS[name]().fit(p, y)
    return mappings


def _fit_catboost_with_boundary(data: PreparedData, split, fitted, config: dict, seed: int):
    AB = np.concatenate([split.A, split.B])
    x_ab = fitted.tabular_preprocessor.transform(data.tabular.iloc[AB])
    model = fit_classical("catboost", x_ab, data.target[AB], config, seed)

    def predict(indices):
        x = fitted.tabular_preprocessor.transform(data.tabular.iloc[indices])
        return model.predict_proba(x)[:, 1]

    return model, predict


def run_transfer(config: dict, data: PreparedData, output_dir: Path, logger: logging.Logger) -> pd.DataFrame:
    experiment = config["experiment"]
    source_index, target_index = _transfer_indices(data, experiment)
    source = data.subset(source_index)
    target = data.subset(target_index)
    split = _development_split(source, config)
    logger.info(
        "protocol=%s source_records=%d target_records=%d target_students=%d",
        experiment["protocol"], len(source.target), len(target.target), len(np.unique(target.groups))
    )
    grid = threshold_grid(
        float(config["thresholds"]["grid_start"]),
        float(config["thresholds"]["grid_stop"]),
        float(config["thresholds"]["grid_step"]),
    )
    rows = []
    calibration_records = []
    importance_records = []
    for seed in config["splits"]["training_seeds"]:
        seed = int(seed)
        logger.info("seed=%d stage=fit_dgtpc", seed)
        fitted = fit_dgtpc(source, split.A, split.B, config, seed)
        dgtpc_raw = {
            "C": fitted.predict(source, split.C),
            "D": fitted.predict(source, split.D),
            "target": fitted.predict(target, np.arange(len(target.target))),
        }
        logger.info("seed=%d stage=fit_catboost", seed)
        cat_model, cat_predict = _fit_catboost_with_boundary(source, split, fitted, config, seed)
        cat_raw = {
            "C": cat_predict(split.C),
            "D": cat_predict(split.D),
            "target": None,
        }
        # The target uses the source-fitted preprocessor and model.
        x_target = fitted.tabular_preprocessor.transform(target.tabular)
        cat_raw["target"] = cat_model.predict_proba(x_target)[:, 1]
        if experiment["name"] == "temporal_transfer":
            feature_names = fitted.tabular_preprocessor.transformer.get_feature_names_out()
            for feature, importance in zip(feature_names, cat_model.feature_importances_):
                importance_records.append(
                    {"seed": seed, "transformed_feature": feature, "importance": float(importance)}
                )

        for model_name, raw in (("DGTPC-Net", dgtpc_raw), ("CatBoost", cat_raw)):
            selection = select_calibrator(
                source.target[split.C],
                raw["C"],
                source.groups[split.C],
                list(config["calibration"]["candidates"]),
                int(config["calibration"]["folds"]),
                int(config["splits"]["partition_seed"]),
                int(config["calibration"]["isotonic_minimum_training_records"]),
                float(config["calibration"]["tie_tolerance"]),
            )
            p_cal_C = selection.mapping.predict(raw["C"])
            p_cal_D = selection.mapping.predict(raw["D"])
            p_cal_target = selection.mapping.predict(raw["target"])
            raw_threshold = select_macro_f1(source.target[split.D], raw["D"], grid)
            calibrated_threshold = select_macro_f1(source.target[split.D], p_cal_D, grid)
            logger.info(
                "seed=%d model=%s calibrator=%s raw_threshold=%.4f calibrated_threshold=%.4f",
                seed, model_name, selection.name, raw_threshold, calibrated_threshold
            )
            fixed_maps = _fit_candidate_maps(
                source.target[split.C],
                raw["C"],
                list(config["calibration"]["candidates"]),
                int(config["calibration"]["isotonic_minimum_training_records"]),
            )
            fixed_target = {
                name: mapping.predict(raw["target"]) for name, mapping in fixed_maps.items()
            }
            raw_metrics = evaluate(
                target.target,
                raw["target"],
                raw_threshold,
                bins=int(config["calibration"]["ece_bins"]),
            )
            calibrated_metrics = evaluate(
                target.target,
                p_cal_target,
                calibrated_threshold,
                bins=int(config["calibration"]["ece_bins"]),
            )
            rows.append(
                {
                    "experiment": experiment["name"],
                    "seed": seed,
                    "model": model_name,
                    "selected_calibrator": selection.name,
                    "selected_epochs": fitted.selected_epochs if model_name == "DGTPC-Net" else np.nan,
                    **{f"raw_{key}": value for key, value in raw_metrics.items()},
                    **{f"calibrated_{key}": value for key, value in calibrated_metrics.items()},
                }
            )
            for index, record_id in enumerate(target.record_id):
                record = {
                    "experiment": experiment["name"],
                    "seed": seed,
                    "model": model_name,
                    "record_id": record_id,
                    "id_student": target.groups[index],
                    "target": int(target.target[index]),
                    "p_raw": float(raw["target"][index]),
                    "p_calibrated": float(p_cal_target[index]),
                    "raw_threshold": float(raw_threshold),
                    "calibrated_threshold": float(calibrated_threshold),
                    "selected_calibrator": selection.name,
                }
                for map_name, values in fixed_target.items():
                    record[f"p_{map_name}"] = float(values[index])
                calibration_records.append(record)
    metrics = pd.DataFrame(rows)
    predictions = pd.DataFrame(calibration_records)
    output_dir.mkdir(parents=True, exist_ok=True)
    metrics.to_csv(output_dir / f"{experiment['name']}_seed_metrics.csv", index=False)
    predictions.to_csv(output_dir / f"{experiment['name']}_predictions.csv", index=False)
    if importance_records:
        pd.DataFrame(importance_records).to_csv(
            output_dir / "temporal_catboost_transformed_importance.csv", index=False
        )
    summary = metrics.groupby("model", as_index=False).mean(numeric_only=True)
    for model in summary["model"]:
        selected = metrics.loc[metrics["model"] == model, "raw_roc_auc"].to_numpy()
        summary.loc[summary["model"] == model, "auc_sd"] = np.std(selected, ddof=1)
    summary.to_csv(output_dir / f"{experiment['name']}_summary.csv", index=False)
    return metrics


def run_main_cv(config: dict, data: PreparedData, output_dir: Path, logger: logging.Logger) -> pd.DataFrame:
    experiment = config["experiment"]
    folds = grouped_folds(
        data.target,
        data.groups,
        int(config["splits"]["outer_folds"]),
        int(config["splits"]["partition_seed"]),
    )
    rows = []
    operating_rows = []
    classical_names = ["catboost", "xgboost", "lightgbm", "random_forest", "logistic_regression"]
    neural_names = ["temporal_gru_fusion", "feature_token_transformer", "residual_mlp"]
    display_name = {
        "catboost": "CatBoost",
        "xgboost": "XGBoost",
        "lightgbm": "LightGBM",
        "random_forest": "Random Forest",
        "logistic_regression": "Logistic Regression",
        "temporal_gru_fusion": "Temporal GRU Fusion",
        "feature_token_transformer": "Feature Token Transformer",
        "residual_mlp": "Residual MLP",
    }
    fixed_threshold = float(config["thresholds"]["fixed_reference"])
    for fold, (development_index, test_index) in enumerate(folds):
        development = data.subset(development_index)
        test = data.subset(test_index)
        split = _development_split(development, config)
        logger.info("outer_fold=%d development=%d test=%d", fold, len(development.target), len(test.target))
        for seed in config["splits"]["training_seeds"]:
            seed = int(seed)
            fitted = fit_dgtpc(development, split.A, split.B, config, seed)
            probability = fitted.predict(test, np.arange(len(test.target)))
            rows.append(
                {"fold": fold, "seed": seed, "model": "DGTPC-Net", **evaluate(test.target, probability, fixed_threshold)}
            )
            p_d = fitted.predict(development, split.D)
            grid = threshold_grid(
                float(config["thresholds"]["grid_start"]),
                float(config["thresholds"]["grid_stop"]),
                float(config["thresholds"]["grid_step"]),
            )
            macro_threshold = select_macro_f1(development.target[split.D], p_d, grid)
            recall_threshold, used_fallback = select_recall_constrained(
                development.target[split.D],
                p_d,
                grid,
                float(config["thresholds"]["recall_target"]),
                float(config["thresholds"]["fallback"]),
            )
            for strategy, threshold, fallback in (
                ("fixed_050", fixed_threshold, False),
                ("macro_f1", macro_threshold, False),
                ("recall_constrained", recall_threshold, used_fallback),
            ):
                operating_rows.append(
                    {
                        "fold": fold,
                        "seed": seed,
                        "strategy": strategy,
                        "fallback": int(fallback),
                        **evaluate(test.target, probability, threshold),
                    }
                )
            AB = np.concatenate([split.A, split.B])
            preprocessor = build_preprocessor(development.manifest).fit(development.tabular.iloc[AB])
            x_ab = preprocessor.transform(development.tabular.iloc[AB])
            x_test = preprocessor.transform(test.tabular)
            for name in classical_names:
                model = fit_classical(name, x_ab, development.target[AB], config, seed)
                probability = model.predict_proba(x_test)[:, 1]
                rows.append(
                    {"fold": fold, "seed": seed, "model": display_name[name], **evaluate(test.target, probability, fixed_threshold)}
                )
            for name in neural_names:
                model = fit_neural_baseline(name, development, split.A, split.B, config, seed)
                probability = model.predict(test, np.arange(len(test.target)))
                rows.append(
                    {"fold": fold, "seed": seed, "model": display_name[name], **evaluate(test.target, probability, fixed_threshold)}
                )
    seed_metrics = pd.DataFrame(rows)
    seed_metrics.to_csv(output_dir / "main_cv_seed_metrics.csv", index=False)
    operating = pd.DataFrame(operating_rows)
    operating.to_csv(output_dir / "main_cv_operating_points.csv", index=False)
    fold_metrics = seed_metrics.groupby(["model", "fold"], as_index=False).mean(numeric_only=True)
    output_rows = []
    for model, group in fold_metrics.groupby("model"):
        row = {"model": model}
        for column in [
            "roc_auc", "pr_auc", "accuracy", "balanced_accuracy", "macro_f1",
            "dropout_precision", "dropout_recall", "brier", "ece",
        ]:
            row[column] = group[column].mean()
            row[f"{column}_sd"] = group[column].std(ddof=1)
        output_rows.append(row)
    table = pd.DataFrame(output_rows)
    table.to_csv(output_dir / "table_07.csv", index=False)
    fold_operating = operating.groupby(["strategy", "fold"], as_index=False).mean(numeric_only=True)
    table_08 = fold_operating.groupby("strategy", as_index=False).mean(numeric_only=True)
    for column in ["threshold", "accuracy", "balanced_accuracy", "macro_f1", "dropout_precision", "dropout_recall"]:
        values = fold_operating.groupby("strategy")[column].std(ddof=1)
        table_08[f"{column}_sd"] = table_08["strategy"].map(values)
    fallback_count = operating.groupby("strategy")["fallback"].sum()
    table_08["fallback_frequency"] = table_08["strategy"].map(fallback_count).astype(int)
    table_08.to_csv(output_dir / "table_08.csv", index=False)
    return table


def _variant_control(name: str):
    return {
        "full": (ForwardControl(), False, False),
        "no_teacher_distillation": (ForwardControl(), True, False),
        "no_reliability_branch": (ForwardControl(disable_reliability=True), False, False),
        "safety_factor_fixed_one": (ForwardControl(safety_factor_fixed_one=True), False, False),
        "no_prototype_memory": (ForwardControl(disable_prototypes=True), False, False),
        "no_brier_regularization": (ForwardControl(), False, True),
        "no_temporal_branch": (ForwardControl(disable_temporal=True), False, False),
    }[name]


def run_ablations(config: dict, data: PreparedData, output_dir: Path, logger: logging.Logger) -> pd.DataFrame:
    source_index, target_index = _transfer_indices(data, config["experiment"])
    source, target = data.subset(source_index), data.subset(target_index)
    split = _development_split(source, config)
    grid = threshold_grid()
    rows = []
    for variant in config["experiment"]["variants"]:
        control, disable_distillation, disable_brier = _variant_control(variant)
        for seed in config["splits"]["training_seeds"]:
            seed = int(seed)
            logger.info("variant=%s seed=%d", variant, seed)
            fitted = fit_dgtpc(
                source,
                split.A,
                split.B,
                config,
                seed,
                control=control,
                disable_distillation=disable_distillation,
                disable_brier=disable_brier,
            )
            p_d = fitted.predict(source, split.D)
            threshold = select_macro_f1(source.target[split.D], p_d, grid)
            p_target = fitted.predict(target, np.arange(len(target.target)))
            rows.append(
                {"variant": variant, "seed": seed, **evaluate(target.target, p_target, threshold)}
            )
    seed_metrics = pd.DataFrame(rows)
    seed_metrics.to_csv(output_dir / "ablation_seed_metrics.csv", index=False)
    summary = seed_metrics.groupby("variant", as_index=False).mean(numeric_only=True)
    auc_sd = seed_metrics.groupby("variant")["roc_auc"].std(ddof=1)
    summary["auc_sd"] = summary["variant"].map(auc_sd)
    summary.to_csv(output_dir / "table_10.csv", index=False)
    return summary


def run_robustness(config: dict, data: PreparedData, output_dir: Path, logger: logging.Logger) -> pd.DataFrame:
    source_index, target_index = _transfer_indices(data, config["experiment"])
    source, target = data.subset(source_index), data.subset(target_index)
    split = _development_split(source, config)
    rows = []
    grid = threshold_grid()
    for seed in config["splits"]["training_seeds"]:
        seed = int(seed)
        fitted = fit_dgtpc(source, split.A, split.B, config, seed)
        threshold = select_macro_f1(source.target[split.D], fitted.predict(source, split.D), grid)
        tab, seq, mask, rel = _transformed(
            target,
            np.arange(len(target.target)),
            fitted.tabular_preprocessor,
            fitted.sequence_standardizer,
        )

        def evaluate_arrays(label, tabular, sequence, control=ForwardControl()):
            probability = _predict_arrays(
                fitted.model, tabular, sequence, mask, rel, 1024, control
            )
            rows.append({"condition": label, "seed": seed, **evaluate(target.target, probability, threshold)})

        evaluate_arrays("none", tab, seq)
        rng_sequence = np.random.default_rng(int(config["robustness"]["gaussian_seed"]) + seed)
        rng_tabular = np.random.default_rng(int(config["robustness"]["gaussian_seed"]) + 1000 + seed)
        numeric_slice = fitted.tabular_preprocessor.transformer.output_indices_["numeric"]
        for strength in config["robustness"]["gaussian_strengths"]:
            sequence_probability = []
            tabular_probability = []
            for _ in range(int(config["robustness"]["repetitions"])):
                noisy_sequence = seq.copy()
                noise = rng_sequence.normal(0.0, float(strength), size=seq.shape).astype(np.float32)
                noisy_sequence += noise * mask[:, :, None]
                sequence_probability.append(
                    _predict_arrays(fitted.model, tab, noisy_sequence, mask, rel, 1024, ForwardControl())
                )
                noisy_tabular = tab.copy()
                noisy_tabular[:, numeric_slice] += rng_tabular.normal(
                    0.0, float(strength), size=noisy_tabular[:, numeric_slice].shape
                ).astype(np.float32)
                tabular_probability.append(
                    _predict_arrays(fitted.model, noisy_tabular, seq, mask, rel, 1024, ForwardControl())
                )
            for label, probabilities in (
                (f"sequence_gaussian_{strength:.2f}", sequence_probability),
                (f"tabular_gaussian_{strength:.2f}", tabular_probability),
            ):
                metric_rows = [evaluate(target.target, p, threshold) for p in probabilities]
                mean_metric = pd.DataFrame(metric_rows).mean(numeric_only=True).to_dict()
                rows.append({"condition": label, "seed": seed, **mean_metric})
        evaluate_arrays("reliability_branch_occlusion", tab, seq, ForwardControl(disable_reliability=True))
        evaluate_arrays("sequence_branch_occlusion", tab, seq, ForwardControl(disable_temporal=True))
        evaluate_arrays("prototype_memory_occlusion", tab, seq, ForwardControl(disable_prototypes=True))
        permutation_metrics = []
        rng_permutation = np.random.default_rng(int(config["robustness"]["tabular_permutation_seed"]) + seed)
        for _ in range(int(config["robustness"]["repetitions"])):
            permuted = tab[rng_permutation.permutation(len(tab))]
            probability = _predict_arrays(
                fitted.model, permuted, seq, mask, rel, 1024, ForwardControl()
            )
            permutation_metrics.append(evaluate(target.target, probability, threshold))
        rows.append(
            {
                "condition": "tabular_block_permutation",
                "seed": seed,
                **pd.DataFrame(permutation_metrics).mean(numeric_only=True).to_dict(),
            }
        )
    seed_metrics = pd.DataFrame(rows)
    seed_metrics.to_csv(output_dir / "robustness_seed_metrics.csv", index=False)
    summary = seed_metrics.groupby("condition", as_index=False).mean(numeric_only=True)
    summary.to_csv(output_dir / "table_12_and_15.csv", index=False)
    return summary


def run_experiment(config_path: str | Path) -> Path:
    config = load_config(config_path)
    repository_root = Path(config_path).resolve().parent.parent
    processed_dir = repository_root / config["project"]["processed_dir"]
    output_dir = repository_root / config["project"]["output_dir"]
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = _logger(output_dir / "logs", config["experiment"]["name"])
    logger.info("repository_version=1.0.0 experiment=%s", config["experiment"]["name"])
    data = load_prepared(processed_dir)
    name = config["experiment"]["name"]
    if name == "main_cv":
        run_main_cv(config, data, output_dir, logger)
    elif name in {"ccc_transfer", "temporal_transfer"}:
        run_transfer(config, data, output_dir, logger)
    elif name == "temporal_retraining_ablations":
        run_ablations(config, data, output_dir, logger)
    elif name == "fixed_model_robustness":
        run_robustness(config, data, output_dir, logger)
    else:
        raise KeyError(name)
    logger.info("experiment=%s status=completed", name)
    return output_dir

