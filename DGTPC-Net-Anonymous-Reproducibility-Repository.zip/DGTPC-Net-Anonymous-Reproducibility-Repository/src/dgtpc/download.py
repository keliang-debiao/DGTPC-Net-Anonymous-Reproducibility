from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

import requests

from .utils import sha256_file, write_json


FIGSHARE_API = "https://api.figshare.com/v2/articles/{article_id}"


def _select_archive(files: list[dict], preferred_name: str) -> dict:
    exact = [item for item in files if item.get("name", "").lower() == preferred_name.lower()]
    if exact:
        return exact[0]
    archives = [item for item in files if item.get("name", "").lower().endswith(".zip")]
    if len(archives) != 1:
        names = [item.get("name") for item in files]
        raise RuntimeError(f"Could not select one OULAD archive from: {names}")
    return archives[0]


def download_oulad(output_dir: str | Path, article_id: int, archive_name: str) -> Path:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    response = requests.get(FIGSHARE_API.format(article_id=article_id), timeout=60)
    response.raise_for_status()
    metadata = response.json()
    selected = _select_archive(metadata.get("files", []), archive_name)
    archive_path = output_dir / selected["name"]
    with requests.get(selected["download_url"], stream=True, timeout=180) as transfer:
        transfer.raise_for_status()
        with archive_path.open("wb") as handle:
            shutil.copyfileobj(transfer.raw, handle)
    digest = sha256_file(archive_path)
    with zipfile.ZipFile(archive_path) as archive:
        archive.extractall(output_dir)
    write_json(
        output_dir / "download_record.json",
        {
            "figshare_article_id": article_id,
            "file_id": selected.get("id"),
            "file_name": selected.get("name"),
            "file_size": selected.get("size"),
            "sha256": digest,
        },
    )
    return archive_path

