from __future__ import annotations

import numpy as np

from .metrics import classification_metrics


def threshold_grid(start: float = 0.01, stop: float = 0.99, step: float = 0.01) -> np.ndarray:
    count = int(round((stop - start) / step)) + 1
    return np.round(np.linspace(start, stop, count), 10)


def select_macro_f1(y: np.ndarray, p: np.ndarray, grid: np.ndarray) -> float:
    rows = []
    for threshold in grid:
        metric = classification_metrics(y, p, float(threshold))
        rows.append((metric["macro_f1"], metric["dropout_recall"], -float(threshold), float(threshold)))
    return max(rows)[-1]


def select_recall_constrained(
    y: np.ndarray, p: np.ndarray, grid: np.ndarray, recall_target: float = 0.85, fallback: float = 0.0
) -> tuple[float, bool]:
    valid = []
    for threshold in grid:
        metric = classification_metrics(y, p, float(threshold))
        if metric["dropout_recall"] >= recall_target:
            valid.append((metric["dropout_precision"], float(threshold)))
    if not valid:
        return float(fallback), True
    return max(valid)[1], False

