from __future__ import annotations

import torch


def weighted_focal_loss(
    probability: torch.Tensor,
    target: torch.Tensor,
    positive_weight: float,
    gamma: float = 2.0,
) -> torch.Tensor:
    probability = probability.clamp(1.0e-7, 1.0 - 1.0e-7)
    target = target.float()
    positive = positive_weight * target * (1.0 - probability).pow(gamma) * torch.log(probability)
    negative = (1.0 - target) * probability.pow(gamma) * torch.log(1.0 - probability)
    return -(positive + negative).mean()


def distillation_loss(probability: torch.Tensor, teacher_probability: torch.Tensor) -> torch.Tensor:
    probability = probability.clamp(1.0e-7, 1.0 - 1.0e-7)
    teacher_probability = teacher_probability.float()
    return -(
        teacher_probability * torch.log(probability)
        + (1.0 - teacher_probability) * torch.log(1.0 - probability)
    ).mean()


def brier_loss(probability: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return torch.mean((probability - target.float()) ** 2)


def combined_loss(
    probability: torch.Tensor,
    target: torch.Tensor,
    teacher_probability: torch.Tensor,
    positive_weight: float,
    gamma: float,
    focal_weight: float,
    distillation_weight: float,
    brier_weight: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    focal = weighted_focal_loss(probability, target, positive_weight, gamma)
    distill = distillation_loss(probability, teacher_probability)
    brier = brier_loss(probability, target)
    total = focal_weight * focal + distillation_weight * distill + brier_weight * brier
    parts = {
        "total": float(total.detach().cpu()),
        "focal": float(focal.detach().cpu()),
        "distillation": float(distill.detach().cpu()),
        "brier": float(brier.detach().cpu()),
    }
    return total, parts


def renormalized_weights(disable_distillation: bool, disable_brier: bool) -> dict[str, float]:
    weights = {
        "focal": 0.62,
        "distillation": 0.0 if disable_distillation else 0.28,
        "brier": 0.0 if disable_brier else 0.10,
    }
    total = sum(weights.values())
    return {name: value / total for name, value in weights.items()}

