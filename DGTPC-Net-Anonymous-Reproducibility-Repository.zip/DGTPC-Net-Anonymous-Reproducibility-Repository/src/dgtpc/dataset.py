from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .utils import read_json


@dataclass
class PreparedData:
    tabular: pd.DataFrame
    reliability: np.ndarray
    sequence: np.ndarray
    sequence_mask: np.ndarray
    groups: np.ndarray
    target: np.ndarray
    record_id: np.ndarray
    manifest: dict

    def subset(self, indices: np.ndarray) -> "PreparedData":
        return PreparedData(
            tabular=self.tabular.iloc[indices].reset_index(drop=True),
            reliability=self.reliability[indices],
            sequence=self.sequence[indices],
            sequence_mask=self.sequence_mask[indices],
            groups=self.groups[indices],
            target=self.target[indices],
            record_id=self.record_id[indices],
            manifest=self.manifest,
        )


def load_prepared(processed_dir: str | Path) -> PreparedData:
    processed_dir = Path(processed_dir)
    tabular = pd.read_csv(processed_dir / "tabular.csv", low_memory=False)
    reliability_frame = pd.read_csv(processed_dir / "reliability.csv")
    sequence_file = np.load(processed_dir / "sequences.npz", allow_pickle=False)
    sequence_ids = sequence_file["record_id"].astype(str)
    record_ids = tabular["record_id"].astype(str).to_numpy()
    if not np.array_equal(sequence_ids, record_ids):
        raise ValueError("Sequence and tabular record order differs")
    reliability_frame = reliability_frame.set_index("record_id").loc[record_ids]
    reliability_columns = [
        column for column in reliability_frame.columns if column != "record_id"
    ]
    return PreparedData(
        tabular=tabular,
        reliability=reliability_frame[reliability_columns].to_numpy(dtype=np.float32),
        sequence=sequence_file["sequence"].astype(np.float32),
        sequence_mask=sequence_file["mask"].astype(np.float32),
        groups=tabular["id_student"].to_numpy(),
        target=tabular["target"].to_numpy(dtype=np.int64),
        record_id=record_ids,
        manifest=read_json(processed_dir / "feature_manifest.json"),
    )

