from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from sklearn.metrics import log_loss
from torch.utils.data import DataLoader, Dataset

from .dataset import PreparedData
from .losses import combined_loss, renormalized_weights
from .model import DGTPCNet, ForwardControl
from .preprocess import SequenceStandardizer, TabularPreprocessor, build_preprocessor
from .teacher import grouped_teacher_oof_from_frame
from .utils import set_seed


class ArrayDataset(Dataset):
    def __init__(self, tabular, sequence, mask, reliability, target, teacher):
        self.tabular = torch.as_tensor(tabular, dtype=torch.float32)
        self.sequence = torch.as_tensor(sequence, dtype=torch.float32)
        self.mask = torch.as_tensor(mask, dtype=torch.float32)
        self.reliability = torch.as_tensor(reliability, dtype=torch.float32)
        self.target = torch.as_tensor(target, dtype=torch.float32)
        self.teacher = torch.as_tensor(teacher, dtype=torch.float32)

    def __len__(self):
        return len(self.target)

    def __getitem__(self, index):
        return (
            self.tabular[index],
            self.sequence[index],
            self.mask[index],
            self.reliability[index],
            self.target[index],
            self.teacher[index],
        )


def _device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _build_model(config: dict, tabular_dim: int, activity_dim: int, reliability_dim: int) -> DGTPCNet:
    architecture = config["architecture"]
    return DGTPCNet(
        tabular_dim=tabular_dim,
        activity_dim=activity_dim,
        reliability_dim=reliability_dim,
        hidden_dim=int(architecture["hidden_dim"]),
        residual_blocks=int(architecture["residual_blocks"]),
        prototypes=int(architecture["prototypes"]),
        conv_channels=int(architecture["conv_channels"]),
        conv_kernels=list(architecture["conv_kernels"]),
        dropout=float(architecture["dropout"]),
    )


def _train_epochs(
    model: DGTPCNet,
    dataset: ArrayDataset,
    config: dict,
    epochs: int,
    positive_weight: float,
    control: ForwardControl,
    disable_distillation: bool,
    disable_brier: bool,
) -> None:
    device = _device()
    model.to(device)
    loader = DataLoader(
        dataset,
        batch_size=int(config["optimization"]["batch_size"]),
        shuffle=True,
        drop_last=False,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["optimization"]["learning_rate"]),
        weight_decay=float(config["optimization"]["weight_decay"]),
    )
    weights = renormalized_weights(disable_distillation, disable_brier)
    for _ in range(epochs):
        model.train()
        for batch in loader:
            tabular, sequence, mask, reliability, target, teacher = [item.to(device) for item in batch]
            output = model(tabular, sequence, mask, reliability, control=control)
            loss, _ = combined_loss(
                output["probability"],
                target,
                teacher,
                positive_weight=positive_weight,
                gamma=float(config["optimization"]["focal_gamma"]),
                focal_weight=weights["focal"],
                distillation_weight=weights["distillation"],
                brier_weight=weights["brier"],
            )
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()


def _predict_arrays(
    model: DGTPCNet,
    tabular: np.ndarray,
    sequence: np.ndarray,
    mask: np.ndarray,
    reliability: np.ndarray,
    batch_size: int,
    control: ForwardControl,
    return_details: bool = False,
):
    device = _device()
    model.to(device)
    model.eval()
    probability = []
    details: dict[str, list[np.ndarray]] = {}
    with torch.no_grad():
        for start in range(0, len(tabular), batch_size):
            stop = min(len(tabular), start + batch_size)
            output = model(
                torch.as_tensor(tabular[start:stop], dtype=torch.float32, device=device),
                torch.as_tensor(sequence[start:stop], dtype=torch.float32, device=device),
                torch.as_tensor(mask[start:stop], dtype=torch.float32, device=device),
                torch.as_tensor(reliability[start:stop], dtype=torch.float32, device=device),
                control=control,
            )
            probability.append(output["probability"].cpu().numpy())
            if return_details:
                for key, value in output.items():
                    if key == "probability":
                        continue
                    details.setdefault(key, []).append(value.cpu().numpy())
    combined = np.concatenate(probability)
    if not return_details:
        return combined
    return combined, {key: np.concatenate(values) for key, values in details.items()}


def _fit_preprocessing(data: PreparedData, indices: np.ndarray):
    tabular = build_preprocessor(data.manifest).fit(data.tabular.iloc[indices])
    sequence = SequenceStandardizer().fit(data.sequence[indices], data.sequence_mask[indices])
    return tabular, sequence


def _transformed(data: PreparedData, indices: np.ndarray, tabular, sequence):
    return (
        tabular.transform(data.tabular.iloc[indices]),
        sequence.transform(data.sequence[indices], data.sequence_mask[indices]),
        data.sequence_mask[indices].astype(np.float32),
        data.reliability[indices].astype(np.float32),
    )


@dataclass
class FittedDGTPC:
    model: DGTPCNet
    tabular_preprocessor: TabularPreprocessor
    sequence_standardizer: SequenceStandardizer
    selected_epochs: int
    positive_weight: float
    control: ForwardControl
    seed: int

    def predict(self, data: PreparedData, indices: np.ndarray, return_details: bool = False):
        tabular, sequence, mask, reliability = _transformed(
            data, indices, self.tabular_preprocessor, self.sequence_standardizer
        )
        return _predict_arrays(
            self.model,
            tabular,
            sequence,
            mask,
            reliability,
            batch_size=1024,
            control=self.control,
            return_details=return_details,
        )


def fit_dgtpc(
    data: PreparedData,
    A: np.ndarray,
    B: np.ndarray,
    config: dict,
    seed: int,
    control: ForwardControl | None = None,
    disable_distillation: bool = False,
    disable_brier: bool = False,
) -> FittedDGTPC:
    set_seed(seed)
    control = ForwardControl() if control is None else control
    stage_tabular, stage_sequence = _fit_preprocessing(data, A)
    A_tab, A_seq, A_mask, A_rel = _transformed(data, A, stage_tabular, stage_sequence)
    B_tab, B_seq, B_mask, B_rel = _transformed(data, B, stage_tabular, stage_sequence)
    teacher_A = grouped_teacher_oof_from_frame(
        data.tabular.iloc[A].reset_index(drop=True),
        data.target[A],
        data.groups[A],
        data.manifest,
        config,
    )
    positive_weight_A = float((data.target[A] == 0).sum() / max(1, (data.target[A] == 1).sum()))
    model = _build_model(config, A_tab.shape[1], A_seq.shape[2], A_rel.shape[1])
    device = _device()
    model.to(device)
    loader = DataLoader(
        ArrayDataset(A_tab, A_seq, A_mask, A_rel, data.target[A], teacher_A),
        batch_size=int(config["optimization"]["batch_size"]),
        shuffle=True,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["optimization"]["learning_rate"]),
        weight_decay=float(config["optimization"]["weight_decay"]),
    )
    weights = renormalized_weights(disable_distillation, disable_brier)
    best_nll = float("inf")
    best_epoch = 1
    stale = 0
    maximum_epochs = int(config["optimization"]["maximum_epochs"])
    patience = int(config["optimization"]["early_stopping_patience"])
    min_delta = float(config["optimization"]["early_stopping_min_delta"])
    for epoch in range(1, maximum_epochs + 1):
        model.train()
        for batch in loader:
            tab, seq, mask, rel, target, teacher = [item.to(device) for item in batch]
            output = model(tab, seq, mask, rel, control=control)
            loss, _ = combined_loss(
                output["probability"],
                target,
                teacher,
                positive_weight_A,
                float(config["optimization"]["focal_gamma"]),
                weights["focal"],
                weights["distillation"],
                weights["brier"],
            )
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
        probability_B = _predict_arrays(
            model,
            B_tab,
            B_seq,
            B_mask,
            B_rel,
            int(config["optimization"]["batch_size"]),
            control,
        )
        nll = float(log_loss(data.target[B], probability_B, labels=[0, 1]))
        if nll < best_nll - min_delta:
            best_nll = nll
            best_epoch = epoch
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break

    final_indices = np.concatenate([A, B])
    final_tabular, final_sequence = _fit_preprocessing(data, final_indices)
    AB_tab, AB_seq, AB_mask, AB_rel = _transformed(
        data, final_indices, final_tabular, final_sequence
    )
    teacher_AB = grouped_teacher_oof_from_frame(
        data.tabular.iloc[final_indices].reset_index(drop=True),
        data.target[final_indices],
        data.groups[final_indices],
        data.manifest,
        config,
    )
    positive_weight_AB = float(
        (data.target[final_indices] == 0).sum() / max(1, (data.target[final_indices] == 1).sum())
    )
    set_seed(seed)
    final_model = _build_model(config, AB_tab.shape[1], AB_seq.shape[2], AB_rel.shape[1])
    final_dataset = ArrayDataset(
        AB_tab, AB_seq, AB_mask, AB_rel, data.target[final_indices], teacher_AB
    )
    _train_epochs(
        final_model,
        final_dataset,
        config,
        best_epoch,
        positive_weight_AB,
        control,
        disable_distillation,
        disable_brier,
    )
    return FittedDGTPC(
        model=final_model,
        tabular_preprocessor=final_tabular,
        sequence_standardizer=final_sequence,
        selected_epochs=best_epoch,
        positive_weight=positive_weight_AB,
        control=control,
        seed=seed,
    )

