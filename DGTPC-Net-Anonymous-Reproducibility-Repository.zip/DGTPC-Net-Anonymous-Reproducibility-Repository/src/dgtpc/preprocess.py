from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


NON_FEATURE_COLUMNS = {"record_id", "id_student", "target", "presentation_year"}


@dataclass
class TabularPreprocessor:
    categorical_columns: list[str]
    numeric_columns: list[str]
    transformer: ColumnTransformer | None = None

    def fit(self, frame: pd.DataFrame) -> "TabularPreprocessor":
        categorical = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("one_hot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
            ]
        )
        numeric = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
            ]
        )
        self.transformer = ColumnTransformer(
            [("categorical", categorical, self.categorical_columns), ("numeric", numeric, self.numeric_columns)],
            remainder="drop",
            sparse_threshold=0.0,
        )
        self.transformer.fit(frame)
        return self

    def transform(self, frame: pd.DataFrame) -> np.ndarray:
        if self.transformer is None:
            raise RuntimeError("TabularPreprocessor has not been fitted")
        return np.asarray(self.transformer.transform(frame), dtype=np.float32)

    def fit_transform(self, frame: pd.DataFrame) -> np.ndarray:
        return self.fit(frame).transform(frame)


@dataclass
class SequenceStandardizer:
    mean_: np.ndarray | None = None
    scale_: np.ndarray | None = None

    def fit(self, sequence: np.ndarray, mask: np.ndarray) -> "SequenceStandardizer":
        observed = mask.astype(bool)
        if observed.sum() == 0:
            self.mean_ = np.zeros(sequence.shape[-1], dtype=np.float32)
            self.scale_ = np.ones(sequence.shape[-1], dtype=np.float32)
            return self
        values = sequence[observed]
        self.mean_ = values.mean(axis=0).astype(np.float32)
        scale = values.std(axis=0, ddof=0).astype(np.float32)
        self.scale_ = np.where(scale < 1.0e-8, 1.0, scale).astype(np.float32)
        return self

    def transform(self, sequence: np.ndarray, mask: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.scale_ is None:
            raise RuntimeError("SequenceStandardizer has not been fitted")
        transformed = (sequence - self.mean_[None, None, :]) / self.scale_[None, None, :]
        return (transformed * mask[:, :, None]).astype(np.float32)


def build_preprocessor(manifest: dict) -> TabularPreprocessor:
    return TabularPreprocessor(
        categorical_columns=list(manifest["categorical_columns"]),
        numeric_columns=list(manifest["numeric_columns"]),
    )

