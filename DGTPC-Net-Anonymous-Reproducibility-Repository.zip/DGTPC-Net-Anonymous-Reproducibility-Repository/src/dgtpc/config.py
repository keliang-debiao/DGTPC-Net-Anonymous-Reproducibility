from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


def _deep_merge(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def load_config(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle) or {}
    paper_config = config.pop("paper_config", None)
    if paper_config is None:
        return config
    base_path = Path(paper_config)
    if not base_path.is_absolute():
        repository_root = path.parent.parent
        base_path = repository_root / base_path
    with base_path.open("r", encoding="utf-8") as handle:
        base = yaml.safe_load(handle) or {}
    return _deep_merge(base, config)

