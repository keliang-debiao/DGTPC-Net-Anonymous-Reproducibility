from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score

from .config import load_config
from .metrics import probability_metrics, reliability_points
from .statistics import holm_adjust, paired_cluster_bootstrap
from .utils import write_json


def build_table_03(repository_root: Path, outputs: Path) -> None:
    audit_path = repository_root / "data/processed/cohort_audit.json"
    if not audit_path.exists():
        return
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    rows = []
    for key, label in (("main_cv", "Main CV"), ("ccc_target", "CCC target"), ("target_2014", "2014 target")):
        row = {"cohort": label, **audit[key]}
        rows.append(row)
    pd.DataFrame(rows).to_csv(outputs / "table_03.csv", index=False)


def build_table_11(outputs: Path) -> None:
    definitions = [
        (outputs / "ccc_transfer_summary.csv", "CCC"),
        (outputs / "temporal_transfer_summary.csv", "2013_to_2014"),
    ]
    rows = []
    for path, validation in definitions:
        if not path.exists():
            continue
        frame = pd.read_csv(path)
        for _, row in frame.iterrows():
            rows.append(
                {
                    "validation": validation,
                    "model": row["model"],
                    "roc_auc": row["raw_roc_auc"],
                    "pr_auc": row["raw_pr_auc"],
                    "accuracy": row["raw_accuracy"],
                    "macro_f1": row["raw_macro_f1"],
                    "auc_sd": row["auc_sd"],
                }
            )
    if rows:
        pd.DataFrame(rows).to_csv(outputs / "table_11.csv", index=False)


def build_tables_12_15(outputs: Path) -> None:
    source = outputs / "table_12_and_15.csv"
    if not source.exists():
        return
    frame = pd.read_csv(source)
    full_auc = float(frame.loc[frame["condition"] == "none", "roc_auc"].iloc[0])
    table_12_conditions = [
        "none",
        "sequence_gaussian_0.10",
        "sequence_gaussian_0.25",
        "sequence_gaussian_0.50",
        "tabular_gaussian_0.10",
        "tabular_gaussian_0.25",
        "tabular_gaussian_0.50",
        "reliability_branch_occlusion",
        "sequence_branch_occlusion",
    ]
    frame.loc[frame["condition"].isin(table_12_conditions)].to_csv(outputs / "table_12.csv", index=False)
    table_15_conditions = [
        "tabular_block_permutation",
        "sequence_branch_occlusion",
        "reliability_branch_occlusion",
        "prototype_memory_occlusion",
    ]
    table_15 = frame.loc[frame["condition"].isin(table_15_conditions), ["condition", "roc_auc"]].copy()
    table_15["roc_auc_drop"] = full_auc - table_15["roc_auc"]
    table_15.to_csv(outputs / "table_15.csv", index=False)


def build_table_16(repository_root: Path, outputs: Path) -> None:
    source = outputs / "temporal_catboost_transformed_importance.csv"
    manifest_path = repository_root / "data/processed/feature_manifest.json"
    if not source.exists() or not manifest_path.exists():
        return
    frame = pd.read_csv(source)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    categorical = sorted(manifest["categorical_columns"], key=len, reverse=True)

    def raw_name(value: str) -> str:
        value = str(value)
        if value.startswith("numeric__"):
            return value[len("numeric__"):]
        if value.startswith("categorical__"):
            remainder = value[len("categorical__"):]
            for name in categorical:
                if remainder == name or remainder.startswith(name + "_"):
                    return name
            return remainder
        return value

    frame["feature"] = frame["transformed_feature"].map(raw_name)
    per_seed = frame.groupby(["seed", "feature"], as_index=False)["importance"].sum()
    table = per_seed.groupby("feature", as_index=False)["importance"].mean()
    table = table.rename(columns={"importance": "importance_score"}).sort_values(
        "importance_score", ascending=False
    )
    table.head(15).to_csv(outputs / "table_16.csv", index=False)


def build_table_13(predictions: pd.DataFrame, bins: int) -> pd.DataFrame:
    rows = []
    definitions = [
        ("DGTPC-Net", "raw", "p_raw"),
        ("DGTPC-Net", "temperature", "p_temperature"),
        ("DGTPC-Net", "platt", "p_platt"),
        ("DGTPC-Net", "isotonic", "p_isotonic"),
        ("DGTPC-Net", "source_selected", "p_calibrated"),
        ("CatBoost", "raw", "p_raw"),
        ("CatBoost", "source_selected", "p_calibrated"),
    ]
    for model, mapping, column in definitions:
        subset = predictions.loc[predictions["model"] == model]
        if column not in subset.columns or subset[column].isna().all():
            continue
        seed_rows = []
        for seed, group in subset.groupby("seed"):
            metric = probability_metrics(
                group["target"].to_numpy(), group[column].to_numpy(), bins=bins
            )
            seed_rows.append(metric)
        mean = pd.DataFrame(seed_rows).mean(numeric_only=True).to_dict()
        rows.append({"model": model, "mapping": mapping, **mean})
    return pd.DataFrame(rows)


def _aligned_seed_frames(predictions: pd.DataFrame):
    aligned = {}
    for seed in sorted(predictions["seed"].unique()):
        seed_frame = predictions.loc[predictions["seed"] == seed]
        left = seed_frame.loc[seed_frame["model"] == "DGTPC-Net"].sort_values("record_id")
        right = seed_frame.loc[seed_frame["model"] == "CatBoost"].sort_values("record_id")
        if not np.array_equal(left["record_id"].to_numpy(), right["record_id"].to_numpy()):
            raise ValueError(f"Prediction alignment failed for seed {seed}")
        aligned[int(seed)] = (left.reset_index(drop=True), right.reset_index(drop=True))
    return aligned


def build_table_14(predictions: pd.DataFrame, config: dict) -> pd.DataFrame:
    aligned = _aligned_seed_frames(predictions)
    first_left = next(iter(aligned.values()))[0]
    groups = first_left["id_student"].to_numpy()
    definitions = [
        ("ROC-AUC", "raw", "roc_auc"),
        ("PR-AUC (AP)", "raw", "pr_auc"),
        ("Macro-F1", "raw_threshold", "macro_f1"),
        ("Brier", "calibrated", "brier"),
        ("ECE", "calibrated", "ece"),
    ]
    results = []
    bins = int(config["calibration"]["ece_bins"])

    def metric_value(frame, metric, weights):
        y = frame["target"].to_numpy()
        if metric == "roc_auc":
            return roc_auc_score(y, frame["p_raw"], sample_weight=weights)
        if metric == "pr_auc":
            return average_precision_score(y, frame["p_raw"], sample_weight=weights)
        if metric == "macro_f1":
            prediction = (frame["p_raw"] >= frame["raw_threshold"]).astype(int)
            return f1_score(y, prediction, average="macro", sample_weight=weights)
        if metric in {"brier", "ece"}:
            return probability_metrics(
                y, frame["p_calibrated"].to_numpy(), bins=bins, sample_weight=weights
            )[metric]
        raise KeyError(metric)

    for metric_name, probability_version, metric in definitions:
        def statistic(weights, metric=metric):
            differences = []
            for left, right in aligned.values():
                differences.append(
                    metric_value(left, metric, weights) - metric_value(right, metric, weights)
                )
            return float(np.mean(differences))

        bootstrap = paired_cluster_bootstrap(
            groups,
            statistic,
            replicates=int(config["bootstrap"]["replicates"]),
            seed=int(config["bootstrap"]["seed"]),
            confidence_level=float(config["bootstrap"]["confidence_level"]),
        )
        results.append(
            {
                "metric": metric_name,
                "probability_version": probability_version,
                "effect": bootstrap["effect"],
                "ci_low": bootstrap["ci_low"],
                "ci_high": bootstrap["ci_high"],
                "raw_p": bootstrap["p_value"],
            }
        )
    table = pd.DataFrame(results)
    table["holm_p"] = holm_adjust(table["raw_p"].to_numpy())
    return table


def _curve_with_intervals(frame: pd.DataFrame, probability_column: str, bins: int, replicates: int, seed: int):
    record = frame.groupby(["record_id", "id_student", "target"], as_index=False)[probability_column].mean()
    y = record["target"].to_numpy()
    p = record[probability_column].to_numpy()
    groups = record["id_student"].to_numpy()
    points = reliability_points(y, p, bins=bins)
    edges = np.linspace(0.0, 1.0, bins + 1)
    bin_index = np.minimum(np.digitize(p, edges[1:-1], right=False), bins - 1)
    rng = np.random.default_rng(seed)
    unique = np.unique(groups)
    rates = {point["bin"]: [] for point in points}
    for _ in range(replicates):
        sampled = rng.choice(unique, size=len(unique), replace=True)
        values, counts = np.unique(sampled, return_counts=True)
        multiplicity = dict(zip(values.tolist(), counts.tolist()))
        weights = np.asarray([multiplicity.get(value, 0) for value in groups], dtype=float)
        for bin_number in rates:
            selected = bin_index == bin_number
            local = weights[selected]
            if local.sum() > 0:
                rates[bin_number].append(float(np.average(y[selected], weights=local)))
    for point in points:
        distribution = np.asarray(rates[point["bin"]], dtype=float)
        point["ci_low"], point["ci_high"] = np.quantile(distribution, [0.025, 0.975])
    return pd.DataFrame(points)


def build_figure_13(predictions: pd.DataFrame, config: dict, output_path: Path) -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Nimbus Roman", "DejaVu Serif"],
            "axes.edgecolor": "#444444",
            "axes.linewidth": 0.8,
            "font.size": 11,
        }
    )
    styles = [
        ("DGTPC-Net", "p_raw", "DGTPC-Net raw", "#4C78A8", "--", "o"),
        ("DGTPC-Net", "p_calibrated", "DGTPC-Net source-calibrated", "#4C78A8", "-", "s"),
        ("CatBoost", "p_raw", "CatBoost raw", "#E07B39", "--", "o"),
        ("CatBoost", "p_calibrated", "CatBoost source-calibrated", "#E07B39", "-", "s"),
    ]
    figure, axis = plt.subplots(figsize=(12.8, 7.2), dpi=300)
    axis.plot([0, 1], [0, 1], color="#777777", linestyle=(0, (4, 3)), linewidth=1.2, label="Ideal calibration")
    for offset, (model, column, label, color, linestyle, marker) in enumerate(styles):
        frame = predictions.loc[predictions["model"] == model]
        curve = _curve_with_intervals(
            frame,
            column,
            int(config["calibration"]["ece_bins"]),
            int(config["bootstrap"]["replicates"]),
            int(config["bootstrap"]["seed"]) + offset,
        )
        axis.fill_between(
            curve["mean_probability"], curve["ci_low"], curve["ci_high"], color=color, alpha=0.10, linewidth=0
        )
        axis.plot(
            curve["mean_probability"],
            curve["observed_rate"],
            color=color,
            linestyle=linestyle,
            marker=marker,
            markersize=4.5,
            linewidth=1.6,
            label=label,
        )
    axis.set_xlim(0, 1)
    axis.set_ylim(0, 1)
    axis.set_xlabel("Mean predicted probability")
    axis.set_ylabel("Observed dropout rate")
    axis.grid(True, color="#DDDDDD", linewidth=0.6, alpha=0.75)
    axis.legend(loc="upper left", frameon=True, edgecolor="#CCCCCC")
    figure.tight_layout()
    figure.savefig(output_path, dpi=300, facecolor="white")
    plt.close(figure)


def _target_deviation(repository_root: Path, outputs: Path) -> dict:
    result = {}
    target_dir = repository_root / "manuscript_targets"
    for target_path in sorted(target_dir.glob("*.csv")):
        output_path = outputs / target_path.name
        result[target_path.name] = {
            "target_present": True,
            "generated_present": output_path.exists(),
        }
    return result


def build_reports(config_path: str | Path) -> Path:
    config = load_config(config_path)
    repository_root = Path(config_path).resolve().parent.parent
    outputs = repository_root / config["project"]["output_dir"]
    outputs.mkdir(parents=True, exist_ok=True)
    build_table_03(repository_root, outputs)
    build_table_11(outputs)
    build_tables_12_15(outputs)
    build_table_16(repository_root, outputs)
    predictions_path = outputs / "temporal_transfer_predictions.csv"
    if predictions_path.exists():
        predictions = pd.read_csv(predictions_path)
        table_13 = build_table_13(predictions, int(config["calibration"]["ece_bins"]))
        table_13.to_csv(outputs / "table_13.csv", index=False)
        table_14 = build_table_14(predictions, config)
        table_14.to_csv(outputs / "table_14.csv", index=False)
        build_figure_13(predictions, config, outputs / "figure_13.png")
    write_json(
        outputs / "manuscript_target_status.json",
        _target_deviation(repository_root, outputs),
    )
    return outputs

