from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_config


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dgtpc")
    subparsers = parser.add_subparsers(dest="command", required=True)

    download = subparsers.add_parser("download")
    download.add_argument("--config", default="configs/paper.yaml")
    download.add_argument("--output-dir", default="data/raw")

    prepare = subparsers.add_parser("prepare")
    prepare.add_argument("--config", default="configs/paper.yaml")
    prepare.add_argument("--raw-dir", default="data/raw")
    prepare.add_argument("--output-dir", default="data/processed")

    run = subparsers.add_parser("run")
    run.add_argument("--config", required=True)

    report = subparsers.add_parser("report")
    report.add_argument("--config", default="configs/paper.yaml")
    return parser


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "download":
        from .download import download_oulad

        config = load_config(args.config)
        path = download_oulad(
            args.output_dir,
            int(config["data"]["figshare_article_id"]),
            str(config["data"]["target_archive_name"]),
        )
        print(path)
    elif args.command == "prepare":
        from .features import prepare_data

        audit = prepare_data(load_config(args.config), args.raw_dir, args.output_dir)
        print(json.dumps(audit, indent=2, sort_keys=True))
    elif args.command == "run":
        from .runner import run_experiment

        print(run_experiment(args.config))
    elif args.command == "report":
        from .reporting import build_reports

        print(build_reports(args.config))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

