from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold


@dataclass(frozen=True)
class DevelopmentSplit:
    A: np.ndarray
    B: np.ndarray
    C: np.ndarray
    D: np.ndarray
    fold_id: np.ndarray


def grouped_folds(y: np.ndarray, groups: np.ndarray, n_splits: int, seed: int) -> list[tuple[np.ndarray, np.ndarray]]:
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return [(train, test) for train, test in splitter.split(np.zeros(len(y)), y, groups)]


def make_development_split(
    y: np.ndarray,
    groups: np.ndarray,
    seed: int,
    A_folds: list[int],
    B_folds: list[int],
    C_folds: list[int],
    D_folds: list[int],
) -> DevelopmentSplit:
    fold_id = np.full(len(y), -1, dtype=np.int16)
    for fold, (_, holdout) in enumerate(grouped_folds(y, groups, 20, seed)):
        fold_id[holdout] = fold
    if (fold_id < 0).any():
        raise AssertionError("Every development record must receive one fold")

    def collect(folds: list[int]) -> np.ndarray:
        return np.flatnonzero(np.isin(fold_id, np.asarray(folds)))

    split = DevelopmentSplit(
        A=collect(A_folds), B=collect(B_folds), C=collect(C_folds), D=collect(D_folds), fold_id=fold_id
    )
    assert_group_disjoint(groups, [split.A, split.B, split.C, split.D])
    return split


def assert_group_disjoint(groups: np.ndarray, parts: list[np.ndarray]) -> None:
    group_sets = [set(groups[index].tolist()) for index in parts]
    for left in range(len(group_sets)):
        for right in range(left + 1, len(group_sets)):
            overlap = group_sets[left].intersection(group_sets[right])
            if overlap:
                raise AssertionError(f"Student overlap across partitions: {len(overlap)}")


def teacher_oof_folds(y: np.ndarray, groups: np.ndarray, seed: int, n_splits: int = 5):
    for train, holdout in grouped_folds(y, groups, n_splits, seed):
        if set(groups[train]).intersection(set(groups[holdout])):
            raise AssertionError("Teacher fold contains student leakage")
        yield train, holdout

