from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from sklearn.model_selection import StratifiedGroupKFold


EPSILON = 1.0e-7


def _clip(p: np.ndarray) -> np.ndarray:
    return np.clip(np.asarray(p, dtype=float), EPSILON, 1.0 - EPSILON)


def _logit(p: np.ndarray) -> np.ndarray:
    p = _clip(p)
    return np.log(p / (1.0 - p))


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.asarray(x, dtype=float)))


class IdentityMap:
    def fit(self, p, y):
        return self

    def predict(self, p):
        return _clip(p)


class TemperatureMap:
    def __init__(self):
        self.temperature = 1.0

    def fit(self, p, y):
        logits = _logit(p)

        def objective(log_temperature):
            probability = _sigmoid(logits / np.exp(log_temperature))
            return log_loss(y, probability, labels=[0, 1])

        result = minimize_scalar(objective, bounds=(-5.0, 5.0), method="bounded")
        self.temperature = float(np.exp(result.x))
        return self

    def predict(self, p):
        return _clip(_sigmoid(_logit(p) / self.temperature))


class PlattMap:
    def __init__(self):
        self.model = LogisticRegression(C=1.0e6, solver="lbfgs", max_iter=2000)

    def fit(self, p, y):
        self.model.fit(_logit(p).reshape(-1, 1), y)
        return self

    def predict(self, p):
        return _clip(self.model.predict_proba(_logit(p).reshape(-1, 1))[:, 1])


class IsotonicMap:
    def __init__(self):
        self.model = IsotonicRegression(out_of_bounds="clip")

    def fit(self, p, y):
        self.model.fit(np.asarray(p, dtype=float), y)
        return self

    def predict(self, p):
        return _clip(self.model.predict(np.asarray(p, dtype=float)))


MAPPINGS = {
    "identity": IdentityMap,
    "temperature": TemperatureMap,
    "platt": PlattMap,
    "isotonic": IsotonicMap,
}


@dataclass
class CalibrationSelection:
    name: str
    mapping: object
    validation_nll: dict[str, float]


def select_calibrator(
    y: np.ndarray,
    p: np.ndarray,
    groups: np.ndarray,
    candidates: list[str],
    folds: int,
    seed: int,
    isotonic_minimum_training_records: int,
    tie_tolerance: float = 1.0e-6,
) -> CalibrationSelection:
    splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
    fold_indices = list(splitter.split(np.zeros(len(y)), y, groups))
    scores: dict[str, float] = {}
    preference = {name: rank for rank, name in enumerate(candidates)}
    for name in candidates:
        if name == "isotonic" and any(len(train) < isotonic_minimum_training_records for train, _ in fold_indices):
            continue
        held_probability = np.full(len(y), np.nan, dtype=float)
        for train, holdout in fold_indices:
            mapping = MAPPINGS[name]().fit(p[train], y[train])
            held_probability[holdout] = mapping.predict(p[holdout])
        if np.isnan(held_probability).any():
            raise AssertionError("Calibration validation predictions are incomplete")
        scores[name] = float(log_loss(y, _clip(held_probability), labels=[0, 1]))
    if not scores:
        raise RuntimeError("No eligible calibration candidate")
    best_score = min(scores.values())
    tied = [name for name, score in scores.items() if score <= best_score + tie_tolerance]
    selected_name = min(tied, key=lambda name: preference[name])
    final_mapping = MAPPINGS[selected_name]().fit(p, y)
    return CalibrationSelection(selected_name, final_mapping, scores)

