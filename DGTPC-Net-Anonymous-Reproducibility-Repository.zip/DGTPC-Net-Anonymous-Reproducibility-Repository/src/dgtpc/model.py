from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn


class ResidualBlock(nn.Module):
    def __init__(self, dimension: int, dropout: float):
        super().__init__()
        self.norm = nn.LayerNorm(dimension)
        self.network = nn.Sequential(
            nn.Linear(dimension, 2 * dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(2 * dimension, dimension),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.network(self.norm(x))


class TabularEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, blocks: int, dropout: float):
        super().__init__()
        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.blocks = nn.Sequential(*[ResidualBlock(hidden_dim, dropout) for _ in range(blocks)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.blocks(self.input(x))


class TemporalEncoder(nn.Module):
    def __init__(
        self,
        activity_dim: int,
        hidden_dim: int,
        conv_channels: int,
        kernels: list[int],
        dropout: float,
    ):
        super().__init__()
        if hidden_dim % 2:
            raise ValueError("hidden_dim must be even for the bidirectional GRU")
        self.gru = nn.GRU(
            activity_dim,
            hidden_dim // 2,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
        )
        self.attention = nn.Linear(hidden_dim, 1)
        self.convolutions = nn.ModuleList(
            [nn.Conv1d(activity_dim, conv_channels, kernel, padding=kernel // 2) for kernel in kernels]
        )
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim + conv_channels * len(kernels), hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, sequence: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        lengths = mask.sum(dim=1).long().clamp_min(1)
        packed = nn.utils.rnn.pack_padded_sequence(
            sequence, lengths.cpu(), batch_first=True, enforce_sorted=False
        )
        packed_recurrent, _ = self.gru(packed)
        recurrent, _ = nn.utils.rnn.pad_packed_sequence(
            packed_recurrent, batch_first=True, total_length=sequence.shape[1]
        )
        score = self.attention(recurrent).squeeze(-1)
        score = score.masked_fill(mask <= 0, -1.0e4)
        weight = torch.softmax(score, dim=1)
        weight = weight * mask
        weight = weight / weight.sum(dim=1, keepdim=True).clamp_min(1.0e-8)
        recurrent_pool = torch.sum(recurrent * weight.unsqueeze(-1), dim=1)

        conv_input = sequence.transpose(1, 2)
        conv_features = []
        for convolution in self.convolutions:
            value = torch.nn.functional.gelu(convolution(conv_input)).transpose(1, 2)
            value = value.masked_fill(mask.unsqueeze(-1) <= 0, -1.0e4)
            pooled = value.max(dim=1).values
            has_observation = mask.sum(dim=1, keepdim=True) > 0
            pooled = torch.where(has_observation, pooled, torch.zeros_like(pooled))
            conv_features.append(pooled)
        return self.projection(torch.cat([recurrent_pool, *conv_features], dim=1))


class ReliabilityEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


@dataclass(frozen=True)
class ForwardControl:
    disable_temporal: bool = False
    disable_reliability: bool = False
    safety_factor_fixed_one: bool = False
    disable_prototypes: bool = False


class DGTPCNet(nn.Module):
    def __init__(
        self,
        tabular_dim: int,
        activity_dim: int,
        reliability_dim: int,
        hidden_dim: int = 192,
        residual_blocks: int = 3,
        prototypes: int = 12,
        conv_channels: int = 96,
        conv_kernels: list[int] | None = None,
        dropout: float = 0.14,
    ):
        super().__init__()
        conv_kernels = [3, 5] if conv_kernels is None else conv_kernels
        self.tabular_encoder = TabularEncoder(tabular_dim, hidden_dim, residual_blocks, dropout)
        self.temporal_encoder = TemporalEncoder(
            activity_dim, hidden_dim, conv_channels, conv_kernels, dropout
        )
        self.reliability_encoder = ReliabilityEncoder(reliability_dim, hidden_dim, dropout)
        self.base_gate = nn.Linear(hidden_dim * 3, 1)
        self.safety_gate = nn.Linear(hidden_dim * 3 + reliability_dim, 1)
        self.prototypes = nn.Parameter(torch.empty(prototypes, hidden_dim))
        nn.init.xavier_uniform_(self.prototypes)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 2 + prototypes, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        tabular: torch.Tensor,
        sequence: torch.Tensor,
        sequence_mask: torch.Tensor,
        reliability: torch.Tensor,
        control: ForwardControl | None = None,
    ) -> dict[str, torch.Tensor]:
        control = ForwardControl() if control is None else control
        z = self.tabular_encoder(tabular)
        s = self.temporal_encoder(sequence, sequence_mask)
        r = self.reliability_encoder(reliability)
        gate_reliability = reliability
        if control.disable_temporal:
            s = torch.zeros_like(s)
        if control.disable_reliability:
            r = torch.zeros_like(r)
            gate_reliability = torch.zeros_like(reliability)
        base = torch.sigmoid(self.base_gate(torch.cat([z, s, r], dim=1)))
        if control.safety_factor_fixed_one:
            safety = torch.ones_like(base)
        else:
            safety = torch.sigmoid(
                self.safety_gate(torch.cat([z, s, r, gate_reliability], dim=1))
            )
        effective = base * safety
        fused = z + effective * s + (1.0 - effective) * r
        distances = -torch.linalg.vector_norm(
            fused.unsqueeze(1) - self.prototypes.unsqueeze(0), ord=2, dim=2
        )
        if control.disable_prototypes:
            distances = torch.zeros_like(distances)
        logit = self.head(torch.cat([fused, r, distances], dim=1)).squeeze(1)
        probability = torch.sigmoid(logit)
        return {
            "logit": logit,
            "probability": probability,
            "base_gate": base.squeeze(1),
            "safety_factor": safety.squeeze(1),
            "effective_temporal_weight": effective.squeeze(1),
            "fused_representation": fused,
            "reliability_representation": r,
            "prototype_similarity": distances,
        }

