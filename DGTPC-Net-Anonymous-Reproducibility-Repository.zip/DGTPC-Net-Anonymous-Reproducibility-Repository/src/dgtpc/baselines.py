from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from .dataset import PreparedData
from .model import TabularEncoder, TemporalEncoder
from .preprocess import SequenceStandardizer, TabularPreprocessor, build_preprocessor
from .utils import set_seed


def fit_classical(name: str, x: np.ndarray, y: np.ndarray, config: dict, seed: int):
    if name == "logistic_regression":
        params = config["baselines"][name]
        model = LogisticRegression(
            class_weight=params["class_weight"], max_iter=int(params["max_iter"]), random_state=seed
        )
    elif name == "random_forest":
        params = config["baselines"][name]
        model = RandomForestClassifier(
            n_estimators=int(params["n_estimators"]),
            max_depth=int(params["max_depth"]),
            min_samples_leaf=int(params["min_samples_leaf"]),
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        )
    elif name == "xgboost":
        from xgboost import XGBClassifier

        params = config["baselines"][name]
        model = XGBClassifier(
            n_estimators=int(params["n_estimators"]),
            max_depth=int(params["max_depth"]),
            learning_rate=float(params["learning_rate"]),
            subsample=float(params["subsample"]),
            eval_metric="logloss",
            random_state=seed,
            n_jobs=-1,
        )
    elif name == "lightgbm":
        from lightgbm import LGBMClassifier

        params = config["baselines"][name]
        model = LGBMClassifier(
            n_estimators=int(params["n_estimators"]),
            learning_rate=float(params["learning_rate"]),
            num_leaves=int(params["num_leaves"]),
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
            verbosity=-1,
        )
    elif name == "catboost":
        from .teacher import fit_standalone_catboost

        return fit_standalone_catboost(x, y, config, seed)
    else:
        raise KeyError(f"Unknown classical baseline: {name}")
    model.fit(x, y)
    return model


class ResidualMLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, blocks: int, dropout: float):
        super().__init__()
        self.encoder = TabularEncoder(input_dim, hidden_dim, blocks, dropout)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, tabular, sequence, mask):
        return self.head(self.encoder(tabular)).squeeze(1)


class FeatureTokenTransformer(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.value_projection = nn.Linear(1, hidden_dim)
        self.feature_embedding = nn.Parameter(torch.empty(input_dim, hidden_dim))
        nn.init.normal_(self.feature_embedding, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=8,
            dim_feedforward=2 * hidden_dim,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, tabular, sequence, mask):
        token = self.value_projection(tabular.unsqueeze(-1)) + self.feature_embedding.unsqueeze(0)
        return self.head(self.encoder(token).mean(dim=1)).squeeze(1)


class TemporalGRUFusion(nn.Module):
    def __init__(self, tabular_dim: int, activity_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.tabular = TabularEncoder(tabular_dim, hidden_dim, 3, dropout)
        self.temporal = TemporalEncoder(activity_dim, hidden_dim, 96, [3, 5], dropout)
        self.head = nn.Sequential(
            nn.Linear(2 * hidden_dim, hidden_dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden_dim, 1)
        )

    def forward(self, tabular, sequence, mask):
        return self.head(torch.cat([self.tabular(tabular), self.temporal(sequence, mask)], dim=1)).squeeze(1)


def _neural_model(name: str, tabular_dim: int, activity_dim: int, config: dict):
    architecture = config["architecture"]
    hidden = int(architecture["hidden_dim"])
    dropout = float(architecture["dropout"])
    if name == "residual_mlp":
        return ResidualMLP(tabular_dim, hidden, int(architecture["residual_blocks"]), dropout)
    if name == "feature_token_transformer":
        return FeatureTokenTransformer(tabular_dim, hidden, dropout)
    if name == "temporal_gru_fusion":
        return TemporalGRUFusion(tabular_dim, activity_dim, hidden, dropout)
    raise KeyError(name)


def _predict(model, tabular, sequence, mask, batch_size=1024):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()
    output = []
    with torch.no_grad():
        for start in range(0, len(tabular), batch_size):
            stop = min(len(tabular), start + batch_size)
            logit = model(
                torch.as_tensor(tabular[start:stop], dtype=torch.float32, device=device),
                torch.as_tensor(sequence[start:stop], dtype=torch.float32, device=device),
                torch.as_tensor(mask[start:stop], dtype=torch.float32, device=device),
            )
            output.append(torch.sigmoid(logit).cpu().numpy())
    return np.concatenate(output)


def _train(model, tabular, sequence, mask, target, config, epochs, positive_weight):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    dataset = TensorDataset(
        torch.as_tensor(tabular, dtype=torch.float32),
        torch.as_tensor(sequence, dtype=torch.float32),
        torch.as_tensor(mask, dtype=torch.float32),
        torch.as_tensor(target, dtype=torch.float32),
    )
    loader = DataLoader(dataset, batch_size=int(config["optimization"]["batch_size"]), shuffle=True)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["optimization"]["learning_rate"]),
        weight_decay=float(config["optimization"]["weight_decay"]),
    )
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(positive_weight, device=device))
    for _ in range(epochs):
        model.train()
        for tab, seq, seq_mask, y in loader:
            tab, seq, seq_mask, y = tab.to(device), seq.to(device), seq_mask.to(device), y.to(device)
            loss = criterion(model(tab, seq, seq_mask), y)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()


@dataclass
class FittedNeuralBaseline:
    name: str
    model: nn.Module
    tabular_preprocessor: TabularPreprocessor
    sequence_standardizer: SequenceStandardizer
    selected_epochs: int

    def predict(self, data: PreparedData, indices: np.ndarray) -> np.ndarray:
        tab = self.tabular_preprocessor.transform(data.tabular.iloc[indices])
        seq = self.sequence_standardizer.transform(data.sequence[indices], data.sequence_mask[indices])
        return _predict(self.model, tab, seq, data.sequence_mask[indices])


def fit_neural_baseline(
    name: str, data: PreparedData, A: np.ndarray, B: np.ndarray, config: dict, seed: int
) -> FittedNeuralBaseline:
    set_seed(seed)
    tabular_pre = build_preprocessor(data.manifest).fit(data.tabular.iloc[A])
    sequence_pre = SequenceStandardizer().fit(data.sequence[A], data.sequence_mask[A])
    A_tab = tabular_pre.transform(data.tabular.iloc[A])
    B_tab = tabular_pre.transform(data.tabular.iloc[B])
    A_seq = sequence_pre.transform(data.sequence[A], data.sequence_mask[A])
    B_seq = sequence_pre.transform(data.sequence[B], data.sequence_mask[B])
    model = _neural_model(name, A_tab.shape[1], A_seq.shape[2], config)
    positive_weight = float((data.target[A] == 0).sum() / max(1, (data.target[A] == 1).sum()))
    best_nll = float("inf")
    best_epoch = 1
    stale = 0
    for epoch in range(1, int(config["optimization"]["maximum_epochs"]) + 1):
        _train(model, A_tab, A_seq, data.sequence_mask[A], data.target[A], config, 1, positive_weight)
        probability = _predict(model, B_tab, B_seq, data.sequence_mask[B])
        nll = float(log_loss(data.target[B], probability, labels=[0, 1]))
        if nll < best_nll - float(config["optimization"]["early_stopping_min_delta"]):
            best_nll = nll
            best_epoch = epoch
            stale = 0
        else:
            stale += 1
            if stale >= int(config["optimization"]["early_stopping_patience"]):
                break

    AB = np.concatenate([A, B])
    tabular_pre = build_preprocessor(data.manifest).fit(data.tabular.iloc[AB])
    sequence_pre = SequenceStandardizer().fit(data.sequence[AB], data.sequence_mask[AB])
    AB_tab = tabular_pre.transform(data.tabular.iloc[AB])
    AB_seq = sequence_pre.transform(data.sequence[AB], data.sequence_mask[AB])
    set_seed(seed)
    final_model = _neural_model(name, AB_tab.shape[1], AB_seq.shape[2], config)
    positive_weight = float((data.target[AB] == 0).sum() / max(1, (data.target[AB] == 1).sum()))
    _train(
        final_model,
        AB_tab,
        AB_seq,
        data.sequence_mask[AB],
        data.target[AB],
        config,
        best_epoch,
        positive_weight,
    )
    return FittedNeuralBaseline(name, final_model, tabular_pre, sequence_pre, best_epoch)

