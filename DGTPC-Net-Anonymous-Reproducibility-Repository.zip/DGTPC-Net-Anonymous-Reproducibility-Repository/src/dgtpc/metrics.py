from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)


def probability_metrics(y: np.ndarray, p: np.ndarray, bins: int = 15, sample_weight=None) -> dict[str, float]:
    y = np.asarray(y, dtype=int)
    p = np.clip(np.asarray(p, dtype=float), 1.0e-7, 1.0 - 1.0e-7)
    weight = np.ones(len(y), dtype=float) if sample_weight is None else np.asarray(sample_weight, dtype=float)
    weight_sum = weight.sum()
    brier = float(np.sum(weight * (p - y) ** 2) / weight_sum)
    nll = float(log_loss(y, p, sample_weight=weight, labels=[0, 1]))
    edges = np.linspace(0.0, 1.0, bins + 1)
    index = np.minimum(np.digitize(p, edges[1:-1], right=False), bins - 1)
    errors = []
    contributions = []
    for bin_index in range(bins):
        selected = index == bin_index
        if not selected.any():
            continue
        local_weight = weight[selected]
        local_total = local_weight.sum()
        mean_probability = np.average(p[selected], weights=local_weight)
        observed_rate = np.average(y[selected], weights=local_weight)
        error = abs(mean_probability - observed_rate)
        errors.append(error)
        contributions.append(local_total / weight_sum * error)
    return {
        "roc_auc": float(roc_auc_score(y, p, sample_weight=weight)),
        "pr_auc": float(average_precision_score(y, p, sample_weight=weight)),
        "brier": brier,
        "ece": float(np.sum(contributions)),
        "mce": float(max(errors) if errors else 0.0),
        "nll": nll,
    }


def classification_metrics(y: np.ndarray, p: np.ndarray, threshold: float, sample_weight=None) -> dict[str, float]:
    prediction = (np.asarray(p) >= threshold).astype(int)
    return {
        "accuracy": float(accuracy_score(y, prediction, sample_weight=sample_weight)),
        "balanced_accuracy": float(balanced_accuracy_score(y, prediction, sample_weight=sample_weight)),
        "macro_f1": float(f1_score(y, prediction, average="macro", sample_weight=sample_weight)),
        "dropout_precision": float(
            precision_score(y, prediction, pos_label=1, zero_division=0, sample_weight=sample_weight)
        ),
        "dropout_recall": float(
            recall_score(y, prediction, pos_label=1, zero_division=0, sample_weight=sample_weight)
        ),
    }


def evaluate(y: np.ndarray, p: np.ndarray, threshold: float, bins: int = 15, sample_weight=None) -> dict[str, float]:
    result = probability_metrics(y, p, bins=bins, sample_weight=sample_weight)
    result.update(classification_metrics(y, p, threshold, sample_weight=sample_weight))
    result["threshold"] = float(threshold)
    return result


def reliability_points(y: np.ndarray, p: np.ndarray, bins: int = 15, sample_weight=None) -> list[dict]:
    y = np.asarray(y)
    p = np.asarray(p)
    weight = np.ones(len(y), dtype=float) if sample_weight is None else np.asarray(sample_weight, dtype=float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    index = np.minimum(np.digitize(p, edges[1:-1], right=False), bins - 1)
    points = []
    for bin_index in range(bins):
        selected = index == bin_index
        if not selected.any():
            continue
        local_weight = weight[selected]
        points.append(
            {
                "bin": bin_index,
                "count": int(selected.sum()),
                "weight": float(local_weight.sum()),
                "mean_probability": float(np.average(p[selected], weights=local_weight)),
                "observed_rate": float(np.average(y[selected], weights=local_weight)),
            }
        )
    return points

