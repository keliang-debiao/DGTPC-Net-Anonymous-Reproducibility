from __future__ import annotations

from pathlib import Path

import pandas as pd


REQUIRED_TABLES = {
    "student_info": "studentInfo.csv",
    "registration": "studentRegistration.csv",
    "courses": "courses.csv",
    "student_vle": "studentVle.csv",
    "vle": "vle.csv",
    "assessments": "assessments.csv",
    "student_assessment": "studentAssessment.csv",
}


def read_oulad(raw_dir: str | Path) -> dict[str, pd.DataFrame]:
    raw_dir = Path(raw_dir)
    missing = [name for name in REQUIRED_TABLES.values() if not (raw_dir / name).exists()]
    if missing:
        raise FileNotFoundError(f"Missing OULAD tables in {raw_dir}: {missing}")
    return {
        key: pd.read_csv(raw_dir / filename, low_memory=False)
        for key, filename in REQUIRED_TABLES.items()
    }

