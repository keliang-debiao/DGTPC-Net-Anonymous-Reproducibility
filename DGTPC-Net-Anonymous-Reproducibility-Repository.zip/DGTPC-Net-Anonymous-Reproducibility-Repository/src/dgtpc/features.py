from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .cohort import KEYS, construct_midpoint_cohort
from .io import read_oulad
from .utils import write_json


CATEGORICAL_COLUMNS = [
    "gender",
    "region",
    "highest_education",
    "imd_band",
    "age_band",
    "disability",
    "code_module",
    "code_presentation",
]

NUMERIC_BASE_COLUMNS = [
    "date_registration",
    "studied_credits",
    "num_of_prev_attempts",
    "module_presentation_length",
    "horizon",
]


def _vle_features(
    cohort: pd.DataFrame,
    student_vle: pd.DataFrame,
    vle: pd.DataFrame,
    sequence_start_day: int,
    sequence_weeks: int,
) -> tuple[pd.DataFrame, np.ndarray, np.ndarray, list[str]]:
    rows = student_vle.merge(
        cohort[KEYS + ["record_id", "horizon"]], on=KEYS, how="inner", validate="many_to_one"
    )
    rows["date"] = pd.to_numeric(rows["date"], errors="coerce")
    rows["sum_click"] = pd.to_numeric(rows["sum_click"], errors="coerce").fillna(0.0)
    rows = rows.loc[rows["date"].notna() & (rows["date"] <= rows["horizon"])].copy()
    rows = rows.merge(
        vle[["id_site", "code_module", "code_presentation", "activity_type"]],
        on=["id_site", "code_module", "code_presentation"],
        how="left",
        validate="many_to_one",
    )
    rows["activity_type"] = rows["activity_type"].fillna("unknown")

    grouped = rows.groupby("record_id", sort=False)
    aggregate = grouped.agg(
        total_clicks=("sum_click", "sum"),
        active_days=("date", "nunique"),
        resource_degree=("id_site", "nunique"),
        last_activity_day=("date", "max"),
    ).reset_index()
    horizon_map = cohort.set_index("record_id")["horizon"]
    aggregate["days_since_last_activity"] = (
        aggregate["record_id"].map(horizon_map) - aggregate["last_activity_day"]
    )
    aggregate = aggregate.drop(columns=["last_activity_day"])

    for weeks in (4, 8, 16):
        recent = rows.loc[rows["date"] > rows["horizon"] - 7 * weeks]
        values = recent.groupby("record_id")["sum_click"].sum().rename(f"last_{weeks}_weeks_clicks")
        aggregate = aggregate.merge(values, on="record_id", how="left")
    week_12 = rows.loc[(rows["date"] >= 77) & (rows["date"] < 84)]
    week_12_values = week_12.groupby("record_id")["sum_click"].sum().rename("week_clicks_12")
    aggregate = aggregate.merge(week_12_values, on="record_id", how="left").fillna(0.0)

    channels = sorted(rows["activity_type"].astype(str).unique().tolist())
    channel_index = {name: index for index, name in enumerate(channels)}
    record_index = {value: index for index, value in enumerate(cohort["record_id"])}
    sequence = np.zeros((len(cohort), sequence_weeks, len(channels)), dtype=np.float32)
    mask = np.zeros((len(cohort), sequence_weeks), dtype=np.float32)
    for record_index_value, horizon in enumerate(cohort["horizon"].to_numpy()):
        observed_weeks = int(np.floor((float(horizon) - sequence_start_day) / 7.0)) + 1
        mask[record_index_value, : max(1, min(sequence_weeks, observed_weeks))] = 1.0
    rows["week_index"] = np.floor((rows["date"] - sequence_start_day) / 7).astype(int)
    rows = rows.loc[(rows["week_index"] >= 0) & (rows["week_index"] < sequence_weeks)]
    compact = rows.groupby(["record_id", "week_index", "activity_type"], sort=False)["sum_click"].sum()
    for (record_id, week, activity), value in compact.items():
        i = record_index[record_id]
        j = int(week)
        k = channel_index[str(activity)]
        sequence[i, j, k] = np.log1p(float(value))
    return aggregate, sequence, mask, channels


def _assessment_features(
    cohort: pd.DataFrame,
    assessments: pd.DataFrame,
    student_assessment: pd.DataFrame,
) -> pd.DataFrame:
    rows = student_assessment.merge(
        assessments,
        on="id_assessment",
        how="left",
        validate="many_to_one",
        suffixes=("", "_assessment"),
    )
    rows = rows.merge(
        cohort[KEYS + ["record_id", "horizon"]],
        on=KEYS,
        how="inner",
        validate="many_to_one",
    )
    rows["date_submitted"] = pd.to_numeric(rows["date_submitted"], errors="coerce")
    rows["score"] = pd.to_numeric(rows["score"], errors="coerce")
    rows["weight"] = pd.to_numeric(rows["weight"], errors="coerce").fillna(0.0)
    rows["assessment_date"] = pd.to_numeric(rows["date"], errors="coerce")
    rows = rows.loc[
        rows["date_submitted"].notna() & (rows["date_submitted"] <= rows["horizon"])
    ].copy()
    rows["submission_delay"] = rows["date_submitted"] - rows["assessment_date"]
    rows["weighted_score"] = rows["score"] * rows["weight"] / 100.0
    result = rows.groupby("record_id", sort=False).agg(
        n_assess_submitted=("id_assessment", "nunique"),
        total_submitted_assessment_weight=("weight", "sum"),
        weighted_score_sum=("weighted_score", "sum"),
        mean_submission_delay=("submission_delay", "mean"),
        mean_score=("score", "mean"),
        std_score=("score", "std"),
        min_score=("score", "min"),
        max_score=("score", "max"),
    ).reset_index()
    return result


def prepare_data(config: dict, raw_dir: str | Path, output_dir: str | Path) -> dict:
    tables = read_oulad(raw_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cohort_result = construct_midpoint_cohort(
        tables["student_info"],
        tables["registration"],
        tables["courses"],
        midpoint_fraction=float(config["data"]["midpoint_fraction"]),
    )
    cohort = cohort_result.cohort
    vle_aggregate, sequence, sequence_mask, channels = _vle_features(
        cohort,
        tables["student_vle"],
        tables["vle"],
        int(config["data"]["sequence_start_day"]),
        int(config["data"]["sequence_weeks"]),
    )
    assessment = _assessment_features(
        cohort, tables["assessments"], tables["student_assessment"]
    )
    tabular = cohort[
        ["record_id", "id_student", "target", "presentation_year"]
        + CATEGORICAL_COLUMNS
        + NUMERIC_BASE_COLUMNS
    ].copy()
    tabular = tabular.merge(vle_aggregate, on="record_id", how="left")
    tabular = tabular.merge(assessment, on="record_id", how="left")

    evidence = tabular[["record_id"]].copy()
    evidence["no_vle_before_horizon"] = tabular["total_clicks"].isna().astype(np.int8)
    evidence["no_assessment_before_horizon"] = tabular["n_assess_submitted"].isna().astype(np.int8)
    numeric_fill = [column for column in tabular.columns if column not in CATEGORICAL_COLUMNS]
    tabular[numeric_fill] = tabular[numeric_fill].replace([np.inf, -np.inf], np.nan)

    cohort.to_csv(output_dir / "cohort.csv", index=False)
    tabular.to_csv(output_dir / "tabular.csv", index=False)
    evidence.to_csv(output_dir / "reliability.csv", index=False)
    np.savez_compressed(
        output_dir / "sequences.npz",
        sequence=sequence,
        mask=sequence_mask,
        record_id=cohort["record_id"].to_numpy(dtype=str),
    )
    ccc_info = tables["student_info"].loc[tables["student_info"]["code_module"] == "CCC"]
    ccc_registration = tables["registration"].loc[tables["registration"]["code_module"] == "CCC"]
    ccc_result = construct_midpoint_cohort(
        ccc_info, ccc_registration, tables["courses"], midpoint_fraction=float(config["data"]["midpoint_fraction"])
    )
    year_mask_info = tables["student_info"]["code_presentation"].astype(str).str.startswith("2014")
    year_mask_registration = tables["registration"]["code_presentation"].astype(str).str.startswith("2014")
    year_result = construct_midpoint_cohort(
        tables["student_info"].loc[year_mask_info],
        tables["registration"].loc[year_mask_registration],
        tables["courses"],
        midpoint_fraction=float(config["data"]["midpoint_fraction"]),
    )
    ccc_students = set(ccc_result.cohort["id_student"].tolist())
    year_students = set(year_result.cohort["id_student"].tolist())
    ccc_source_count = int(
        ((cohort["code_module"] != "CCC") & (~cohort["id_student"].isin(ccc_students))).sum()
    )
    year_source_count = int(
        ((cohort["presentation_year"] == 2013) & (~cohort["id_student"].isin(year_students))).sum()
    )
    audit = {
        "main_cv": cohort_result.audit,
        "ccc_target": {
            **ccc_result.audit,
            "eligible_source_records_after_group_exclusion": ccc_source_count,
        },
        "target_2014": {
            **year_result.audit,
            "eligible_source_records_after_group_exclusion": year_source_count,
        },
    }
    for cohort_name, expected_values in config["data"].get("expected_counts", {}).items():
        observed_values = audit[cohort_name]
        for field, expected in expected_values.items():
            observed = observed_values.get(field)
            if observed != expected:
                raise AssertionError(
                    f"Cohort audit mismatch for {cohort_name}.{field}: "
                    f"observed={observed}, expected={expected}"
                )
    write_json(output_dir / "cohort_audit.json", audit)
    write_json(
        output_dir / "feature_manifest.json",
        {
            "categorical_columns": CATEGORICAL_COLUMNS,
            "numeric_columns": [
                column
                for column in tabular.columns
                if column
                not in CATEGORICAL_COLUMNS
                + ["record_id", "id_student", "target", "presentation_year"]
            ],
            "reliability_columns": [
                "no_vle_before_horizon",
                "no_assessment_before_horizon",
            ],
            "activity_channels": channels,
            "sequence_start_day": int(config["data"]["sequence_start_day"]),
            "sequence_weeks": int(config["data"]["sequence_weeks"]),
            "grade_availability_assumption": bool(
                config["data"]["grade_availability_assumption"]
            ),
        },
    )
    return audit

