from __future__ import annotations

import subprocess
import sys
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def run(*arguments: str) -> None:
    command = [sys.executable, "-m", "dgtpc.cli", *arguments]
    environment = dict(os.environ)
    source_path = str(ROOT / "src")
    environment["PYTHONPATH"] = source_path + (
        os.pathsep + environment["PYTHONPATH"] if environment.get("PYTHONPATH") else ""
    )
    subprocess.run(command, cwd=ROOT, env=environment, check=True)


def main() -> None:
    run("prepare", "--config", "configs/paper.yaml", "--raw-dir", "data/raw", "--output-dir", "data/processed")
    for config in (
        "configs/main_cv.yaml",
        "configs/ccc_transfer.yaml",
        "configs/temporal_transfer.yaml",
        "configs/ablations.yaml",
        "configs/robustness.yaml",
    ):
        run("run", "--config", config)
    run("report", "--config", "configs/paper.yaml")


if __name__ == "__main__":
    main()

