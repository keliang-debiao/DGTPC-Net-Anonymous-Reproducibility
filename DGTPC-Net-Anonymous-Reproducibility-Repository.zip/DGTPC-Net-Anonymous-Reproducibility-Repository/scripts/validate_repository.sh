#!/usr/bin/env bash
set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repository_root"
export PYTHONPATH="$repository_root/src${PYTHONPATH:+:$PYTHONPATH}"

python -m compileall -q src scripts tests reproduce.py
python scripts/run_tests.py
python scripts/validate_repository.py

