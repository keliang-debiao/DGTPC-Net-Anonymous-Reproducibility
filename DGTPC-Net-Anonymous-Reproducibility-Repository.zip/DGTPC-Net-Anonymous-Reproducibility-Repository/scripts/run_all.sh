#!/usr/bin/env bash
set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repository_root"
export PYTHONPATH="$repository_root/src${PYTHONPATH:+:$PYTHONPATH}"

python reproduce.py
python scripts/compare_results.py

