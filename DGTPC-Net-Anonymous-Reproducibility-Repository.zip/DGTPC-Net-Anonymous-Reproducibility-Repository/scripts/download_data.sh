#!/usr/bin/env bash
set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repository_root"
export PYTHONPATH="$repository_root/src${PYTHONPATH:+:$PYTHONPATH}"

python -m dgtpc.cli download --config configs/paper.yaml --output-dir data/raw

