from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent.parent
TARGETS = ROOT / "manuscript_targets"
OUTPUTS = ROOT / "outputs"

KEYS = {
    "table_03.csv": ["cohort"],
    "table_07.csv": ["model"],
    "table_08.csv": ["strategy"],
    "table_10.csv": ["variant"],
    "table_11.csv": ["validation", "model"],
    "table_13.csv": ["model", "mapping"],
    "table_14.csv": ["metric"],
    "table_15.csv": ["condition"],
    "table_16.csv": ["feature"],
}


def tolerance(name: str, column: str) -> float:
    if name == "table_03.csv" and column != "eligible_event_proportion":
        return 0.0
    if name == "table_16.csv":
        return 5.0e-5
    return 5.5e-4


def compare_file(name: str) -> dict:
    target_path = TARGETS / name
    output_path = OUTPUTS / name
    if not output_path.exists():
        return {"status": "missing", "path": str(output_path.relative_to(ROOT))}
    target = pd.read_csv(target_path)
    output = pd.read_csv(output_path)
    keys = KEYS[name]
    merged = target.merge(output, on=keys, how="outer", suffixes=("_target", "_generated"), indicator=True)
    if not (merged["_merge"] == "both").all():
        return {
            "status": "row_mismatch",
            "unmatched": merged.loc[merged["_merge"] != "both", keys + ["_merge"]].to_dict("records"),
        }
    deviations = []
    for column in target.columns:
        if column in keys or not pd.api.types.is_numeric_dtype(target[column]):
            continue
        target_column = f"{column}_target"
        generated_column = f"{column}_generated"
        if generated_column not in merged:
            deviations.append({"column": column, "reason": "missing_column"})
            continue
        difference = np.abs(merged[target_column].to_numpy() - merged[generated_column].to_numpy())
        allowed = tolerance(name, column)
        for row_index in np.flatnonzero(difference > allowed):
            deviations.append(
                {
                    "key": {key: merged.iloc[row_index][key] for key in keys},
                    "column": column,
                    "target": float(merged.iloc[row_index][target_column]),
                    "generated": float(merged.iloc[row_index][generated_column]),
                    "absolute_difference": float(difference[row_index]),
                    "tolerance": allowed,
                }
            )
    return {"status": "passed" if not deviations else "deviation", "deviations": deviations}


def main() -> None:
    report = {name: compare_file(name) for name in KEYS}
    (OUTPUTS / "manuscript_comparison.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, sort_keys=True))
    if any(item["status"] != "passed" for item in report.values()):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
