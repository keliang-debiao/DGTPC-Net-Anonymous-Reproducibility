from __future__ import annotations

import importlib.util
import inspect
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    path = ROOT / "tests/test_core.py"
    spec = importlib.util.spec_from_file_location("test_core", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    tests = [
        function
        for name, function in inspect.getmembers(module, inspect.isfunction)
        if name.startswith("test_")
    ]
    passed = 0
    skipped = 0
    for function in tests:
        try:
            function()
        except unittest.SkipTest as reason:
            skipped += 1
            print(f"SKIP {function.__name__}: {reason}")
        else:
            passed += 1
            print(f"PASS {function.__name__}")
    print(f"PASS total={passed} skipped={skipped}")


if __name__ == "__main__":
    main()
