from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent

REQUIRED = [
    "README.md",
    "REPRODUCIBILITY.md",
    "DATA.md",
    "requirements.txt",
    "requirements.lock",
    "environment.yml",
    "configs/paper.yaml",
    "src/dgtpc/model.py",
    "src/dgtpc/cohort.py",
    "src/dgtpc/calibration.py",
    "src/dgtpc/statistics.py",
    "scripts/run_all.sh",
    "manuscript_targets/table_03.csv",
    "manuscript_targets/table_07.csv",
    "manuscript_targets/table_08.csv",
    "manuscript_targets/table_10.csv",
    "manuscript_targets/table_11.csv",
    "manuscript_targets/table_13.csv",
    "manuscript_targets/table_14.csv",
    "manuscript_targets/table_15.csv",
    "manuscript_targets/table_16.csv",
]


def main() -> None:
    missing = [item for item in REQUIRED if not (ROOT / item).exists()]
    if missing:
        raise SystemExit(f"Missing required repository items: {missing}")
    forbidden_generated = [
        path
        for path in ROOT.rglob("*")
        if path.is_file() and path.suffix.lower() in {".pt", ".pth", ".joblib", ".parquet"}
    ]
    if forbidden_generated:
        raise SystemExit(f"Generated runtime files are present: {forbidden_generated}")
    result = {
        "status": "passed",
        "required_items": len(REQUIRED),
        "runtime_files_present": 0,
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

