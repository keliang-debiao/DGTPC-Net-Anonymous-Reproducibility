# Reproducibility map

| Manuscript item | Command or stage | Generated artifact |
|---|---|---|
| Table 3 | `dgtpc prepare` | `data/processed/cohort_audit.json`, `outputs/table_03.csv` |
| Table 7 | `dgtpc run --config configs/main_cv.yaml` | `outputs/table_07.csv` |
| Table 8 | `dgtpc run --config configs/main_cv.yaml` | `outputs/table_08.csv` |
| Table 10 | `dgtpc run --config configs/ablations.yaml` | `outputs/table_10.csv` |
| Table 11 | CCC and temporal transfer stages | `outputs/table_11.csv` |
| Table 12 | `dgtpc run --config configs/robustness.yaml` | `outputs/table_12.csv` |
| Table 13 | temporal transfer and report stages | `outputs/table_13.csv` |
| Figure 13 | temporal transfer and report stages | `outputs/figure_13.png` |
| Table 14 | paired student-cluster bootstrap report stage | `outputs/table_14.csv` |
| Table 15 | fixed-model representation operations | `outputs/table_15.csv` |
| Table 16 | standalone temporal CatBoost importance | `outputs/table_16.csv` |

## Seed ownership

- `20260701`: grouped data partition and calibration partition.
- `20260701` through `20260705`: model training.
- `20260711`: paired student-cluster bootstrap.
- `20260721`: joint tabular block permutation.
- `20260722`: Gaussian perturbation.

## Aggregation rules

- Main cross-validation metrics are first calculated for each fold and seed,
  averaged across seeds within a fold, and then summarized across five folds.
- Transfer point estimates are means of five seed-specific metrics on the same
  fixed target cohort.
- Transfer AUC standard deviation is the sample standard deviation across the
  five seed-specific AUC values with denominator four.
- Scalar calibration metrics are calculated per seed and then averaged.
- Bootstrap effects are the mean of five seed-specific paired differences and
  use identical target-student draws for both models.

## Expected data boundaries

The preparation audit should recover 24,498 eligible main-cohort records from
22,620 students, including 2,077 subsequent withdrawals. The CCC target should
contain 2,835 eligible records, and the 2014 target should contain 13,866. A
count mismatch stops the reporting comparison and should be investigated before
model fitting.

