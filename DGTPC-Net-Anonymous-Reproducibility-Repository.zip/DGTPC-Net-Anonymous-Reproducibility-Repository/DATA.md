# Data acquisition and local boundary

The repository uses the publicly available, anonymized Open University
Learning Analytics Dataset (OULAD).

- Figshare DOI: `10.6084/m9.figshare.5081998`
- UCI DOI: `10.24432/C5KK69`

The automated downloader resolves the archive metadata from Figshare article
`5081998`, downloads the archive, records its SHA-256 digest, and extracts the
source tables under `data/raw`.

Required tables:

- `studentInfo.csv`
- `studentRegistration.csv`
- `courses.csv`
- `studentVle.csv`
- `vle.csv`
- `assessments.csv`
- `studentAssessment.csv`

The raw tables and derived per-record files are excluded from the archive.
Eligibility and feature construction are performed locally. Withdrawal dates
and final outcomes are used only for eligibility and target construction and do
not enter the predictor inputs.

Assessment submissions are restricted by recorded submission date. OULAD does
not provide grade-release timestamps; score-derived variables therefore follow
the manuscript's stated availability assumption.

