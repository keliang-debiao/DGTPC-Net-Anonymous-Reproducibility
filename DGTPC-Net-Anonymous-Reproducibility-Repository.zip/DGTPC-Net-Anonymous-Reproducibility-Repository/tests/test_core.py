from __future__ import annotations

from pathlib import Path
import unittest

import numpy as np
import pandas as pd

from dgtpc.calibration import select_calibrator
from dgtpc.cohort import construct_midpoint_cohort
from dgtpc.metrics import probability_metrics
from dgtpc.splits import make_development_split
from dgtpc.statistics import holm_adjust
from dgtpc.thresholds import select_macro_f1, select_recall_constrained, threshold_grid


def test_midpoint_cohort_rules():
    info = pd.DataFrame(
        {
            "code_module": ["AAA"] * 6,
            "code_presentation": ["2013J"] * 6,
            "id_student": np.arange(1, 7),
            "final_result": ["Pass", "Withdrawn", "Withdrawn", "Fail", "Pass", "Unknown"],
        }
    )
    registration = pd.DataFrame(
        {
            "code_module": ["AAA"] * 6,
            "code_presentation": ["2013J"] * 6,
            "id_student": np.arange(1, 7),
            "date_registration": [-5, -2, -1, 60, 0, 0],
            "date_unregistration": [np.nan, 30, 70, np.nan, 80, np.nan],
        }
    )
    courses = pd.DataFrame(
        {"code_module": ["AAA"], "code_presentation": ["2013J"], "module_presentation_length": [100]}
    )
    result = construct_midpoint_cohort(info, registration, courses)
    assert result.audit["withdrawn_on_or_before_horizon"] == 1
    assert result.audit["eligible_records"] == 2
    assert result.audit["subsequent_withdrawals"] == 1
    assert set(result.cohort["id_student"]) == {1, 3}


def test_grouped_development_boundaries():
    groups = np.repeat(np.arange(80), 2)
    y = np.repeat(np.arange(80) % 2, 2)
    split = make_development_split(
        y, groups, 20260701, list(range(12)), [12, 13, 14], [15, 16, 17], [18, 19]
    )
    parts = [set(groups[index]) for index in (split.A, split.B, split.C, split.D)]
    assert sum(len(part) for part in parts) == len(np.unique(groups))
    assert all(not parts[i].intersection(parts[j]) for i in range(4) for j in range(i + 1, 4))


def test_metrics_and_thresholds():
    y = np.asarray([0, 0, 0, 1, 1, 1])
    p = np.asarray([0.05, 0.20, 0.40, 0.55, 0.75, 0.95])
    metrics = probability_metrics(y, p, bins=5)
    assert 0.0 <= metrics["ece"] <= 1.0
    assert metrics["roc_auc"] == 1.0
    grid = threshold_grid(0.1, 0.9, 0.1)
    selected = select_macro_f1(y, p, grid)
    constrained, fallback = select_recall_constrained(y, p, grid, 0.85, 0.0)
    assert selected in grid
    assert constrained in grid
    assert fallback is False


def test_calibration_selection_and_holm():
    rng = np.random.default_rng(20260701)
    groups = np.repeat(np.arange(60), 2)
    y = np.repeat(np.arange(60) % 2, 2)
    p = np.clip(0.15 + 0.70 * y + rng.normal(0, 0.08, len(y)), 0.01, 0.99)
    result = select_calibrator(
        y, p, groups, ["identity", "temperature", "platt"], 3, 20260701, 1000
    )
    assert result.name in {"identity", "temperature", "platt"}
    mapped = result.mapping.predict(p)
    assert np.all((mapped > 0) & (mapped < 1))
    adjusted = holm_adjust(np.asarray([0.01, 0.04, 0.20]))
    assert np.all(adjusted >= np.asarray([0.01, 0.04, 0.20]))


def test_model_source_contains_required_components():
    source = (Path(__file__).resolve().parents[1] / "src/dgtpc/model.py").read_text(encoding="utf-8")
    for token in ("base_gate", "safety_gate", "prototypes", "TemporalEncoder", "ReliabilityEncoder"):
        assert token in source


def test_model_forward_runtime():
    try:
        import torch
    except ImportError as error:
        raise unittest.SkipTest("PyTorch is not installed in the current validation environment") from error
    from dgtpc.model import DGTPCNet

    model = DGTPCNet(tabular_dim=18, activity_dim=7, reliability_dim=2)
    output = model(
        torch.zeros(4, 18),
        torch.zeros(4, 24, 7),
        torch.ones(4, 24),
        torch.zeros(4, 2),
    )
    assert output["probability"].shape == (4,)
    assert output["prototype_similarity"].shape == (4, 12)

